/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Battleship;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.Timer;
import java.awt.event.*;
import java.net.DatagramSocket;
import java.net.SocketException;

/**
 *
 * @author christian
 */
public class PosizionaNavi extends javax.swing.JFrame {

    static int ContatoreNavi = 14;
    private Vector<String> naviPosizionate = new Vector<String>();

    ImageIcon ship = new ImageIcon("ship.png");

    /**
     * Creates new form PosizionaNavi
     */
    public PosizionaNavi() {
        initComponents();
        this.setLocationRelativeTo(null);

    }


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel21 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        label2 = new java.awt.Label();
        label1 = new java.awt.Label();
        jButton1 = new javax.swing.JButton();
        jPanel106 = new javax.swing.JPanel();
        label22 = new java.awt.Label();
        label32 = new java.awt.Label();
        label33 = new java.awt.Label();
        label34 = new java.awt.Label();
        label35 = new java.awt.Label();
        label36 = new java.awt.Label();
        label37 = new java.awt.Label();
        label38 = new java.awt.Label();
        label39 = new java.awt.Label();
        label40 = new java.awt.Label();
        jPanel1 = new javax.swing.JPanel();
        C5 = new javax.swing.JPanel();
        C5ship = new javax.swing.JLabel();
        A2 = new javax.swing.JPanel();
        A2ship = new javax.swing.JLabel();
        A3 = new javax.swing.JPanel();
        A3ship = new javax.swing.JLabel();
        A4 = new javax.swing.JPanel();
        A4ship = new javax.swing.JLabel();
        A5 = new javax.swing.JPanel();
        A5ship = new javax.swing.JLabel();
        A6 = new javax.swing.JPanel();
        A6ship = new javax.swing.JLabel();
        A7 = new javax.swing.JPanel();
        A7ship = new javax.swing.JLabel();
        A8 = new javax.swing.JPanel();
        A8ship = new javax.swing.JLabel();
        A9 = new javax.swing.JPanel();
        A9ship = new javax.swing.JLabel();
        A10 = new javax.swing.JPanel();
        A10ship = new javax.swing.JLabel();
        A1 = new javax.swing.JPanel();
        A1ship = new javax.swing.JLabel();
        B3 = new javax.swing.JPanel();
        B3ship = new javax.swing.JLabel();
        B1 = new javax.swing.JPanel();
        B1ship = new javax.swing.JLabel();
        C1 = new javax.swing.JPanel();
        C1ship = new javax.swing.JLabel();
        D1 = new javax.swing.JPanel();
        D1ship = new javax.swing.JLabel();
        C3 = new javax.swing.JPanel();
        C3ship = new javax.swing.JLabel();
        C2 = new javax.swing.JPanel();
        C2ship = new javax.swing.JLabel();
        D3 = new javax.swing.JPanel();
        D3ship = new javax.swing.JLabel();
        D2 = new javax.swing.JPanel();
        D2ship = new javax.swing.JLabel();
        E3 = new javax.swing.JPanel();
        E3ship = new javax.swing.JLabel();
        E1 = new javax.swing.JPanel();
        E1ship = new javax.swing.JLabel();
        F1 = new javax.swing.JPanel();
        F1ship = new javax.swing.JLabel();
        F2 = new javax.swing.JPanel();
        F2ship = new javax.swing.JLabel();
        F3 = new javax.swing.JPanel();
        F3ship = new javax.swing.JLabel();
        G3 = new javax.swing.JPanel();
        G3ship = new javax.swing.JLabel();
        G2 = new javax.swing.JPanel();
        G2ship = new javax.swing.JLabel();
        G1 = new javax.swing.JPanel();
        G1ship = new javax.swing.JLabel();
        H1 = new javax.swing.JPanel();
        H1ship = new javax.swing.JLabel();
        H2 = new javax.swing.JPanel();
        H2ship = new javax.swing.JLabel();
        H3 = new javax.swing.JPanel();
        H3ship = new javax.swing.JLabel();
        I3 = new javax.swing.JPanel();
        I3ship = new javax.swing.JLabel();
        I2 = new javax.swing.JPanel();
        I2ship = new javax.swing.JLabel();
        I1 = new javax.swing.JPanel();
        I1ship = new javax.swing.JLabel();
        L1 = new javax.swing.JPanel();
        L1ship = new javax.swing.JLabel();
        L2 = new javax.swing.JPanel();
        L2ship = new javax.swing.JLabel();
        L3 = new javax.swing.JPanel();
        L3ship = new javax.swing.JLabel();
        L4 = new javax.swing.JPanel();
        L4ship = new javax.swing.JLabel();
        I4 = new javax.swing.JPanel();
        I4ship = new javax.swing.JLabel();
        E2 = new javax.swing.JPanel();
        E2ship = new javax.swing.JLabel();
        E5 = new javax.swing.JPanel();
        E5ship = new javax.swing.JLabel();
        E6 = new javax.swing.JPanel();
        E6ship = new javax.swing.JLabel();
        E7 = new javax.swing.JPanel();
        E7ship = new javax.swing.JLabel();
        E8 = new javax.swing.JPanel();
        E8ship = new javax.swing.JLabel();
        E9 = new javax.swing.JPanel();
        E9ship = new javax.swing.JLabel();
        E10 = new javax.swing.JPanel();
        E10ship = new javax.swing.JLabel();
        F10 = new javax.swing.JPanel();
        F10ship = new javax.swing.JLabel();
        F9 = new javax.swing.JPanel();
        F9ship = new javax.swing.JLabel();
        F8 = new javax.swing.JPanel();
        F8ship = new javax.swing.JLabel();
        F7 = new javax.swing.JPanel();
        F7ship = new javax.swing.JLabel();
        H6 = new javax.swing.JPanel();
        H6ship = new javax.swing.JLabel();
        F5 = new javax.swing.JPanel();
        F5ship = new javax.swing.JLabel();
        F4 = new javax.swing.JPanel();
        F4ship = new javax.swing.JLabel();
        G4 = new javax.swing.JPanel();
        G4ship = new javax.swing.JLabel();
        D4 = new javax.swing.JPanel();
        D4ship = new javax.swing.JLabel();
        D5 = new javax.swing.JPanel();
        D5ship = new javax.swing.JLabel();
        D6 = new javax.swing.JPanel();
        D6ship = new javax.swing.JLabel();
        D7 = new javax.swing.JPanel();
        D7ship = new javax.swing.JLabel();
        D8 = new javax.swing.JPanel();
        D8ship = new javax.swing.JLabel();
        D9 = new javax.swing.JPanel();
        D9ship = new javax.swing.JLabel();
        D10 = new javax.swing.JPanel();
        D10ship = new javax.swing.JLabel();
        C10 = new javax.swing.JPanel();
        C10ship = new javax.swing.JLabel();
        B10 = new javax.swing.JPanel();
        B10ship = new javax.swing.JLabel();
        B9 = new javax.swing.JPanel();
        B9ship = new javax.swing.JLabel();
        C9 = new javax.swing.JPanel();
        C9ship = new javax.swing.JLabel();
        B7 = new javax.swing.JPanel();
        B7ship = new javax.swing.JLabel();
        B8 = new javax.swing.JPanel();
        B8ship = new javax.swing.JLabel();
        E4 = new javax.swing.JPanel();
        E4ship = new javax.swing.JLabel();
        C7 = new javax.swing.JPanel();
        C7ship = new javax.swing.JLabel();
        B6 = new javax.swing.JPanel();
        B6ship = new javax.swing.JLabel();
        C6 = new javax.swing.JPanel();
        C6ship = new javax.swing.JLabel();
        B5 = new javax.swing.JPanel();
        B5ship = new javax.swing.JLabel();
        C8 = new javax.swing.JPanel();
        C8ship = new javax.swing.JLabel();
        C4 = new javax.swing.JPanel();
        C4ship = new javax.swing.JLabel();
        B4 = new javax.swing.JPanel();
        B4ship = new javax.swing.JLabel();
        H4 = new javax.swing.JPanel();
        H4ship = new javax.swing.JLabel();
        G6 = new javax.swing.JPanel();
        G6ship = new javax.swing.JLabel();
        G5 = new javax.swing.JPanel();
        G5ship = new javax.swing.JLabel();
        H5 = new javax.swing.JPanel();
        H5ship = new javax.swing.JLabel();
        F6 = new javax.swing.JPanel();
        F6ship = new javax.swing.JLabel();
        I6 = new javax.swing.JPanel();
        I6ship = new javax.swing.JLabel();
        I5 = new javax.swing.JPanel();
        I5ship = new javax.swing.JLabel();
        L5 = new javax.swing.JPanel();
        L5ship = new javax.swing.JLabel();
        L6 = new javax.swing.JPanel();
        L6ship = new javax.swing.JLabel();
        L7 = new javax.swing.JPanel();
        L7ship = new javax.swing.JLabel();
        I7 = new javax.swing.JPanel();
        I7ship = new javax.swing.JLabel();
        H7 = new javax.swing.JPanel();
        H7ship = new javax.swing.JLabel();
        G7 = new javax.swing.JPanel();
        G7ship = new javax.swing.JLabel();
        G8 = new javax.swing.JPanel();
        G8ship = new javax.swing.JLabel();
        H8 = new javax.swing.JPanel();
        H8ship = new javax.swing.JLabel();
        I8 = new javax.swing.JPanel();
        I8ship = new javax.swing.JLabel();
        L8 = new javax.swing.JPanel();
        L8ship = new javax.swing.JLabel();
        L9 = new javax.swing.JPanel();
        L9ship = new javax.swing.JLabel();
        L10 = new javax.swing.JPanel();
        L10ship = new javax.swing.JLabel();
        I10 = new javax.swing.JPanel();
        I10ship = new javax.swing.JLabel();
        H10 = new javax.swing.JPanel();
        H10ship = new javax.swing.JLabel();
        G10 = new javax.swing.JPanel();
        G10ship = new javax.swing.JLabel();
        G9 = new javax.swing.JPanel();
        G9ship = new javax.swing.JLabel();
        H9 = new javax.swing.JPanel();
        H9ship = new javax.swing.JLabel();
        I9 = new javax.swing.JPanel();
        I9ship = new javax.swing.JLabel();
        B2 = new javax.swing.JPanel();
        B2ship = new javax.swing.JLabel();
        jPanel105 = new javax.swing.JPanel();
        label21 = new java.awt.Label();
        label23 = new java.awt.Label();
        label24 = new java.awt.Label();
        label25 = new java.awt.Label();
        label26 = new java.awt.Label();
        label27 = new java.awt.Label();
        label28 = new java.awt.Label();
        label29 = new java.awt.Label();
        label30 = new java.awt.Label();
        label31 = new java.awt.Label();
        conteggio = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tempotimer = new javax.swing.JLabel();

        jPanel21.setBackground(new java.awt.Color(204, 204, 204));
        jPanel21.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        jPanel21.setMinimumSize(new java.awt.Dimension(60, 60));

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 56, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 56, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 142, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 128, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(255, 255, 240));
        setUndecorated(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 240));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(0, 49, 83));
        jPanel3.setForeground(new java.awt.Color(255, 255, 240));
        jPanel3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel3MouseDragged(evt);
            }
        });
        jPanel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel3MousePressed(evt);
            }
        });

        label2.setBackground(new java.awt.Color(0, 49, 83));
        label2.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label2.setForeground(new java.awt.Color(255, 255, 240));
        label2.setText("POSIZIONA LE NAVI");

        label1.setBackground(new java.awt.Color(0, 49, 83));
        label1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        label1.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 255, 240));
        label1.setText("X");
        label1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                label1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 745, Short.MAX_VALUE)
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 43));

        jButton1.setBackground(new java.awt.Color(0, 49, 83));
        jButton1.setFont(new java.awt.Font("Georgia", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 240));
        jButton1.setText("RESET");
        jButton1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 121, 28));

        jPanel106.setBackground(new java.awt.Color(0, 49, 83));
        jPanel106.setPreferredSize(new java.awt.Dimension(600, 35));
        jPanel106.setLayout(new java.awt.GridLayout(1, 0));

        label22.setAlignment(java.awt.Label.CENTER);
        label22.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label22.setForeground(new java.awt.Color(255, 255, 240));
        label22.setMinimumSize(new java.awt.Dimension(15, 22));
        label22.setPreferredSize(new java.awt.Dimension(35, 35));
        label22.setText("1");
        jPanel106.add(label22);

        label32.setAlignment(java.awt.Label.CENTER);
        label32.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label32.setForeground(new java.awt.Color(255, 255, 240));
        label32.setMinimumSize(new java.awt.Dimension(15, 22));
        label32.setPreferredSize(new java.awt.Dimension(35, 35));
        label32.setText("2");
        jPanel106.add(label32);

        label33.setAlignment(java.awt.Label.CENTER);
        label33.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label33.setForeground(new java.awt.Color(255, 255, 240));
        label33.setMinimumSize(new java.awt.Dimension(15, 22));
        label33.setPreferredSize(new java.awt.Dimension(35, 35));
        label33.setText("3");
        jPanel106.add(label33);

        label34.setAlignment(java.awt.Label.CENTER);
        label34.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label34.setForeground(new java.awt.Color(255, 255, 240));
        label34.setMinimumSize(new java.awt.Dimension(15, 22));
        label34.setPreferredSize(new java.awt.Dimension(35, 35));
        label34.setText("4");
        jPanel106.add(label34);

        label35.setAlignment(java.awt.Label.CENTER);
        label35.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label35.setForeground(new java.awt.Color(255, 255, 240));
        label35.setMinimumSize(new java.awt.Dimension(15, 22));
        label35.setPreferredSize(new java.awt.Dimension(35, 35));
        label35.setText("5");
        jPanel106.add(label35);

        label36.setAlignment(java.awt.Label.CENTER);
        label36.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label36.setForeground(new java.awt.Color(255, 255, 240));
        label36.setMinimumSize(new java.awt.Dimension(15, 22));
        label36.setPreferredSize(new java.awt.Dimension(35, 35));
        label36.setText("6");
        jPanel106.add(label36);

        label37.setAlignment(java.awt.Label.CENTER);
        label37.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label37.setForeground(new java.awt.Color(255, 255, 240));
        label37.setMinimumSize(new java.awt.Dimension(15, 22));
        label37.setPreferredSize(new java.awt.Dimension(35, 35));
        label37.setText("7");
        jPanel106.add(label37);

        label38.setAlignment(java.awt.Label.CENTER);
        label38.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label38.setForeground(new java.awt.Color(255, 255, 240));
        label38.setMinimumSize(new java.awt.Dimension(15, 22));
        label38.setPreferredSize(new java.awt.Dimension(35, 35));
        label38.setText("8");
        jPanel106.add(label38);

        label39.setAlignment(java.awt.Label.CENTER);
        label39.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label39.setForeground(new java.awt.Color(255, 255, 240));
        label39.setMinimumSize(new java.awt.Dimension(15, 22));
        label39.setPreferredSize(new java.awt.Dimension(35, 35));
        label39.setText("9");
        jPanel106.add(label39);

        label40.setAlignment(java.awt.Label.CENTER);
        label40.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label40.setForeground(new java.awt.Color(255, 255, 240));
        label40.setMinimumSize(new java.awt.Dimension(15, 22));
        label40.setPreferredSize(new java.awt.Dimension(35, 35));
        label40.setText("10");
        jPanel106.add(label40);

        jPanel2.add(jPanel106, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 70, -1, -1));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(600, 600));
        jPanel1.setLayout(null);

        C5.setBackground(new java.awt.Color(255, 255, 240));
        C5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C5.setMinimumSize(new java.awt.Dimension(60, 60));
        C5.setPreferredSize(new java.awt.Dimension(60, 60));
        C5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C5MouseExited(evt);
            }
        });
        C5.setLayout(null);

        C5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C5ship.setFocusable(false);
        C5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C5.add(C5ship);
        C5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C5);
        C5.setBounds(240, 120, 60, 60);

        A2.setBackground(new java.awt.Color(255, 255, 240));
        A2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A2.setMinimumSize(new java.awt.Dimension(60, 60));
        A2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A2MouseExited(evt);
            }
        });
        A2.setLayout(null);

        A2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A2ship.setFocusable(false);
        A2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A2.add(A2ship);
        A2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A2);
        A2.setBounds(60, 0, 60, 60);

        A3.setBackground(new java.awt.Color(255, 255, 240));
        A3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A3.setMinimumSize(new java.awt.Dimension(60, 60));
        A3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A3MouseExited(evt);
            }
        });
        A3.setLayout(null);

        A3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A3ship.setFocusable(false);
        A3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A3.add(A3ship);
        A3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A3);
        A3.setBounds(120, 0, 60, 60);

        A4.setBackground(new java.awt.Color(255, 255, 240));
        A4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A4.setMinimumSize(new java.awt.Dimension(60, 60));
        A4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A4MouseExited(evt);
            }
        });
        A4.setLayout(null);

        A4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A4ship.setFocusable(false);
        A4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A4.add(A4ship);
        A4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A4);
        A4.setBounds(180, 0, 60, 60);

        A5.setBackground(new java.awt.Color(255, 255, 240));
        A5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A5.setMinimumSize(new java.awt.Dimension(60, 60));
        A5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A5MouseExited(evt);
            }
        });
        A5.setLayout(null);

        A5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A5ship.setFocusable(false);
        A5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A5.add(A5ship);
        A5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A5);
        A5.setBounds(240, 0, 60, 60);

        A6.setBackground(new java.awt.Color(255, 255, 240));
        A6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A6.setMinimumSize(new java.awt.Dimension(60, 60));
        A6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A6MouseExited(evt);
            }
        });
        A6.setLayout(null);

        A6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A6ship.setFocusable(false);
        A6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A6.add(A6ship);
        A6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A6);
        A6.setBounds(300, 0, 60, 60);

        A7.setBackground(new java.awt.Color(255, 255, 240));
        A7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A7.setMinimumSize(new java.awt.Dimension(60, 60));
        A7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A7MouseExited(evt);
            }
        });
        A7.setLayout(null);

        A7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A7ship.setFocusable(false);
        A7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A7.add(A7ship);
        A7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A7);
        A7.setBounds(360, 0, 60, 60);

        A8.setBackground(new java.awt.Color(255, 255, 240));
        A8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A8.setMinimumSize(new java.awt.Dimension(60, 60));
        A8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A8MouseExited(evt);
            }
        });
        A8.setLayout(null);

        A8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A8ship.setFocusable(false);
        A8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A8.add(A8ship);
        A8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A8);
        A8.setBounds(420, 0, 60, 60);

        A9.setBackground(new java.awt.Color(255, 255, 240));
        A9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A9.setMinimumSize(new java.awt.Dimension(60, 60));
        A9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A9MouseExited(evt);
            }
        });
        A9.setLayout(null);

        A9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A9ship.setFocusable(false);
        A9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A9.add(A9ship);
        A9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A9);
        A9.setBounds(480, 0, 60, 60);

        A10.setBackground(new java.awt.Color(255, 255, 240));
        A10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A10.setMinimumSize(new java.awt.Dimension(60, 60));
        A10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A10MouseExited(evt);
            }
        });
        A10.setLayout(null);

        A10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A10ship.setFocusable(false);
        A10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A10.add(A10ship);
        A10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A10);
        A10.setBounds(540, 0, 60, 60);

        A1.setBackground(new java.awt.Color(255, 255, 240));
        A1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        A1.setForeground(new java.awt.Color(255, 255, 240));
        A1.setMinimumSize(new java.awt.Dimension(60, 60));
        A1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                A1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                A1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                A1MouseExited(evt);
            }
        });
        A1.setLayout(null);

        A1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        A1ship.setFocusable(false);
        A1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        A1.add(A1ship);
        A1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(A1);
        A1.setBounds(0, 0, 60, 60);

        B3.setBackground(new java.awt.Color(255, 255, 240));
        B3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B3.setMinimumSize(new java.awt.Dimension(60, 60));
        B3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B3MouseExited(evt);
            }
        });
        B3.setLayout(null);

        B3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B3ship.setFocusable(false);
        B3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B3.add(B3ship);
        B3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B3);
        B3.setBounds(120, 60, 60, 60);

        B1.setBackground(new java.awt.Color(255, 255, 240));
        B1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B1.setMinimumSize(new java.awt.Dimension(60, 60));
        B1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B1MouseExited(evt);
            }
        });
        B1.setLayout(null);

        B1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B1ship.setFocusable(false);
        B1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B1.add(B1ship);
        B1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B1);
        B1.setBounds(0, 60, 60, 60);

        C1.setBackground(new java.awt.Color(255, 255, 240));
        C1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C1.setMinimumSize(new java.awt.Dimension(60, 60));
        C1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C1MouseExited(evt);
            }
        });
        C1.setLayout(null);

        C1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C1ship.setFocusable(false);
        C1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C1.add(C1ship);
        C1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C1);
        C1.setBounds(0, 120, 60, 60);

        D1.setBackground(new java.awt.Color(255, 255, 240));
        D1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D1.setMinimumSize(new java.awt.Dimension(60, 60));
        D1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D1MouseExited(evt);
            }
        });
        D1.setLayout(null);

        D1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D1ship.setFocusable(false);
        D1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D1.add(D1ship);
        D1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D1);
        D1.setBounds(0, 180, 60, 60);

        C3.setBackground(new java.awt.Color(255, 255, 240));
        C3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C3.setMinimumSize(new java.awt.Dimension(60, 60));
        C3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C3MouseExited(evt);
            }
        });
        C3.setLayout(null);

        C3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C3ship.setFocusable(false);
        C3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C3.add(C3ship);
        C3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C3);
        C3.setBounds(120, 120, 60, 60);

        C2.setBackground(new java.awt.Color(255, 255, 240));
        C2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C2.setMinimumSize(new java.awt.Dimension(60, 60));
        C2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C2MouseExited(evt);
            }
        });
        C2.setLayout(null);

        C2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C2ship.setFocusable(false);
        C2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C2.add(C2ship);
        C2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C2);
        C2.setBounds(60, 120, 60, 60);

        D3.setBackground(new java.awt.Color(255, 255, 240));
        D3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D3.setMinimumSize(new java.awt.Dimension(60, 60));
        D3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D3MouseExited(evt);
            }
        });
        D3.setLayout(null);

        D3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D3ship.setFocusable(false);
        D3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D3.add(D3ship);
        D3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D3);
        D3.setBounds(120, 180, 60, 60);

        D2.setBackground(new java.awt.Color(255, 255, 240));
        D2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D2.setMinimumSize(new java.awt.Dimension(60, 60));
        D2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D2MouseExited(evt);
            }
        });
        D2.setLayout(null);

        D2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D2ship.setFocusable(false);
        D2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D2.add(D2ship);
        D2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D2);
        D2.setBounds(60, 180, 60, 60);

        E3.setBackground(new java.awt.Color(255, 255, 240));
        E3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E3.setMinimumSize(new java.awt.Dimension(60, 60));
        E3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E3MouseExited(evt);
            }
        });
        E3.setLayout(null);

        E3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E3ship.setFocusable(false);
        E3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E3.add(E3ship);
        E3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E3);
        E3.setBounds(120, 240, 60, 60);

        E1.setBackground(new java.awt.Color(255, 255, 240));
        E1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E1.setMinimumSize(new java.awt.Dimension(60, 60));
        E1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E1MouseExited(evt);
            }
        });
        E1.setLayout(null);

        E1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E1ship.setFocusable(false);
        E1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E1.add(E1ship);
        E1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E1);
        E1.setBounds(0, 240, 60, 60);

        F1.setBackground(new java.awt.Color(255, 255, 240));
        F1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F1.setMinimumSize(new java.awt.Dimension(60, 60));
        F1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F1MouseExited(evt);
            }
        });
        F1.setLayout(null);

        F1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F1ship.setFocusable(false);
        F1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F1.add(F1ship);
        F1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F1);
        F1.setBounds(0, 300, 60, 60);

        F2.setBackground(new java.awt.Color(255, 255, 240));
        F2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F2.setMinimumSize(new java.awt.Dimension(60, 60));
        F2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F2MouseExited(evt);
            }
        });
        F2.setLayout(null);

        F2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F2ship.setFocusable(false);
        F2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F2.add(F2ship);
        F2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F2);
        F2.setBounds(60, 300, 60, 60);

        F3.setBackground(new java.awt.Color(255, 255, 240));
        F3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F3.setMinimumSize(new java.awt.Dimension(60, 60));
        F3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F3MouseExited(evt);
            }
        });
        F3.setLayout(null);

        F3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F3ship.setFocusable(false);
        F3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F3.add(F3ship);
        F3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F3);
        F3.setBounds(120, 300, 60, 60);

        G3.setBackground(new java.awt.Color(255, 255, 240));
        G3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G3.setMinimumSize(new java.awt.Dimension(60, 60));
        G3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G3MouseExited(evt);
            }
        });
        G3.setLayout(null);

        G3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G3ship.setFocusable(false);
        G3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G3.add(G3ship);
        G3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G3);
        G3.setBounds(120, 360, 60, 60);

        G2.setBackground(new java.awt.Color(255, 255, 240));
        G2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G2.setMinimumSize(new java.awt.Dimension(60, 60));
        G2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G2MouseExited(evt);
            }
        });
        G2.setLayout(null);

        G2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G2ship.setFocusable(false);
        G2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G2.add(G2ship);
        G2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G2);
        G2.setBounds(60, 360, 60, 60);

        G1.setBackground(new java.awt.Color(255, 255, 240));
        G1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G1.setMinimumSize(new java.awt.Dimension(60, 60));
        G1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G1MouseExited(evt);
            }
        });
        G1.setLayout(null);

        G1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G1ship.setFocusable(false);
        G1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G1.add(G1ship);
        G1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G1);
        G1.setBounds(0, 360, 60, 60);

        H1.setBackground(new java.awt.Color(255, 255, 240));
        H1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H1.setMinimumSize(new java.awt.Dimension(60, 60));
        H1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H1MouseExited(evt);
            }
        });
        H1.setLayout(null);

        H1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H1ship.setFocusable(false);
        H1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H1.add(H1ship);
        H1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H1);
        H1.setBounds(0, 420, 60, 60);

        H2.setBackground(new java.awt.Color(255, 255, 240));
        H2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H2.setMinimumSize(new java.awt.Dimension(60, 60));
        H2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H2MouseExited(evt);
            }
        });
        H2.setLayout(null);

        H2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H2ship.setFocusable(false);
        H2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H2.add(H2ship);
        H2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H2);
        H2.setBounds(60, 420, 60, 60);

        H3.setBackground(new java.awt.Color(255, 255, 240));
        H3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H3.setMinimumSize(new java.awt.Dimension(60, 60));
        H3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H3MouseExited(evt);
            }
        });
        H3.setLayout(null);

        H3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H3ship.setFocusable(false);
        H3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H3.add(H3ship);
        H3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H3);
        H3.setBounds(120, 420, 60, 60);

        I3.setBackground(new java.awt.Color(255, 255, 240));
        I3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I3.setMinimumSize(new java.awt.Dimension(60, 60));
        I3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I3MouseExited(evt);
            }
        });
        I3.setLayout(null);

        I3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I3ship.setFocusable(false);
        I3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I3.add(I3ship);
        I3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I3);
        I3.setBounds(120, 480, 60, 60);

        I2.setBackground(new java.awt.Color(255, 255, 240));
        I2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I2.setMinimumSize(new java.awt.Dimension(60, 60));
        I2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I2MouseExited(evt);
            }
        });
        I2.setLayout(null);

        I2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I2ship.setFocusable(false);
        I2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I2.add(I2ship);
        I2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I2);
        I2.setBounds(60, 480, 60, 60);

        I1.setBackground(new java.awt.Color(255, 255, 240));
        I1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I1.setMinimumSize(new java.awt.Dimension(60, 60));
        I1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I1MouseExited(evt);
            }
        });
        I1.setLayout(null);

        I1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I1ship.setFocusable(false);
        I1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I1.add(I1ship);
        I1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I1);
        I1.setBounds(0, 480, 60, 60);

        L1.setBackground(new java.awt.Color(255, 255, 240));
        L1.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L1.setMinimumSize(new java.awt.Dimension(60, 60));
        L1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L1MouseExited(evt);
            }
        });
        L1.setLayout(null);

        L1ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L1ship.setFocusable(false);
        L1ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L1.add(L1ship);
        L1ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L1);
        L1.setBounds(0, 540, 60, 60);

        L2.setBackground(new java.awt.Color(255, 255, 240));
        L2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L2.setMinimumSize(new java.awt.Dimension(60, 60));
        L2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L2MouseExited(evt);
            }
        });
        L2.setLayout(null);

        L2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L2ship.setFocusable(false);
        L2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L2.add(L2ship);
        L2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L2);
        L2.setBounds(60, 540, 60, 60);

        L3.setBackground(new java.awt.Color(255, 255, 240));
        L3.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L3.setMinimumSize(new java.awt.Dimension(60, 60));
        L3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L3MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L3MouseExited(evt);
            }
        });
        L3.setLayout(null);

        L3ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L3ship.setFocusable(false);
        L3ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L3.add(L3ship);
        L3ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L3);
        L3.setBounds(120, 540, 60, 60);

        L4.setBackground(new java.awt.Color(255, 255, 240));
        L4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L4.setMinimumSize(new java.awt.Dimension(60, 60));
        L4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L4MouseExited(evt);
            }
        });
        L4.setLayout(null);

        L4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L4ship.setFocusable(false);
        L4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L4.add(L4ship);
        L4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L4);
        L4.setBounds(180, 540, 60, 60);

        I4.setBackground(new java.awt.Color(255, 255, 240));
        I4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I4.setMinimumSize(new java.awt.Dimension(60, 60));
        I4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I4MouseExited(evt);
            }
        });
        I4.setLayout(null);

        I4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I4ship.setFocusable(false);
        I4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I4.add(I4ship);
        I4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I4);
        I4.setBounds(180, 480, 60, 60);

        E2.setBackground(new java.awt.Color(255, 255, 240));
        E2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E2.setMinimumSize(new java.awt.Dimension(60, 60));
        E2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E2MouseExited(evt);
            }
        });
        E2.setLayout(null);

        E2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E2ship.setFocusable(false);
        E2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E2.add(E2ship);
        E2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E2);
        E2.setBounds(60, 240, 60, 60);

        E5.setBackground(new java.awt.Color(255, 255, 240));
        E5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E5.setMinimumSize(new java.awt.Dimension(60, 60));
        E5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E5MouseExited(evt);
            }
        });
        E5.setLayout(null);

        E5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E5ship.setFocusable(false);
        E5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E5.add(E5ship);
        E5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E5);
        E5.setBounds(240, 240, 60, 60);

        E6.setBackground(new java.awt.Color(255, 255, 240));
        E6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E6.setMinimumSize(new java.awt.Dimension(60, 60));
        E6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E6MouseExited(evt);
            }
        });
        E6.setLayout(null);

        E6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E6ship.setFocusable(false);
        E6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E6.add(E6ship);
        E6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E6);
        E6.setBounds(300, 240, 60, 60);

        E7.setBackground(new java.awt.Color(255, 255, 240));
        E7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E7.setMinimumSize(new java.awt.Dimension(60, 60));
        E7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E7MouseExited(evt);
            }
        });
        E7.setLayout(null);

        E7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E7ship.setFocusable(false);
        E7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E7.add(E7ship);
        E7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E7);
        E7.setBounds(360, 240, 60, 60);

        E8.setBackground(new java.awt.Color(255, 255, 240));
        E8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E8.setMinimumSize(new java.awt.Dimension(60, 60));
        E8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E8MouseExited(evt);
            }
        });
        E8.setLayout(null);

        E8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E8ship.setFocusable(false);
        E8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E8.add(E8ship);
        E8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E8);
        E8.setBounds(420, 240, 60, 60);

        E9.setBackground(new java.awt.Color(255, 255, 240));
        E9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E9.setMinimumSize(new java.awt.Dimension(60, 60));
        E9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E9MouseExited(evt);
            }
        });
        E9.setLayout(null);

        E9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E9ship.setFocusable(false);
        E9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E9.add(E9ship);
        E9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E9);
        E9.setBounds(480, 240, 60, 60);

        E10.setBackground(new java.awt.Color(255, 255, 240));
        E10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E10.setMinimumSize(new java.awt.Dimension(60, 60));
        E10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E10MouseExited(evt);
            }
        });
        E10.setLayout(null);

        E10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E10ship.setFocusable(false);
        E10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E10.add(E10ship);
        E10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E10);
        E10.setBounds(540, 240, 60, 60);

        F10.setBackground(new java.awt.Color(255, 255, 240));
        F10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F10.setMinimumSize(new java.awt.Dimension(60, 60));
        F10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F10MouseExited(evt);
            }
        });
        F10.setLayout(null);

        F10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F10ship.setFocusable(false);
        F10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F10.add(F10ship);
        F10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F10);
        F10.setBounds(540, 300, 60, 60);

        F9.setBackground(new java.awt.Color(255, 255, 240));
        F9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F9.setMinimumSize(new java.awt.Dimension(60, 60));
        F9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F9MouseExited(evt);
            }
        });
        F9.setLayout(null);

        F9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F9ship.setFocusable(false);
        F9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F9.add(F9ship);
        F9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F9);
        F9.setBounds(480, 300, 60, 60);

        F8.setBackground(new java.awt.Color(255, 255, 240));
        F8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F8.setMinimumSize(new java.awt.Dimension(60, 60));
        F8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F8MouseExited(evt);
            }
        });
        F8.setLayout(null);

        F8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F8ship.setFocusable(false);
        F8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F8.add(F8ship);
        F8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F8);
        F8.setBounds(420, 300, 60, 60);

        F7.setBackground(new java.awt.Color(255, 255, 240));
        F7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F7.setMinimumSize(new java.awt.Dimension(60, 60));
        F7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F7MouseExited(evt);
            }
        });
        F7.setLayout(null);

        F7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F7ship.setFocusable(false);
        F7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F7.add(F7ship);
        F7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F7);
        F7.setBounds(360, 300, 60, 60);

        H6.setBackground(new java.awt.Color(255, 255, 240));
        H6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H6.setMinimumSize(new java.awt.Dimension(60, 60));
        H6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H6MouseExited(evt);
            }
        });
        H6.setLayout(null);

        H6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H6ship.setFocusable(false);
        H6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H6.add(H6ship);
        H6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H6);
        H6.setBounds(300, 420, 60, 60);

        F5.setBackground(new java.awt.Color(255, 255, 240));
        F5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F5.setMinimumSize(new java.awt.Dimension(60, 60));
        F5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F5MouseExited(evt);
            }
        });
        F5.setLayout(null);

        F5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F5ship.setFocusable(false);
        F5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F5.add(F5ship);
        F5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F5);
        F5.setBounds(240, 300, 60, 60);

        F4.setBackground(new java.awt.Color(255, 255, 240));
        F4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F4.setMinimumSize(new java.awt.Dimension(60, 60));
        F4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F4MouseExited(evt);
            }
        });
        F4.setLayout(null);

        F4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F4ship.setFocusable(false);
        F4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F4.add(F4ship);
        F4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F4);
        F4.setBounds(180, 300, 60, 60);

        G4.setBackground(new java.awt.Color(255, 255, 240));
        G4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G4.setMinimumSize(new java.awt.Dimension(60, 60));
        G4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G4MouseExited(evt);
            }
        });
        G4.setLayout(null);

        G4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G4ship.setFocusable(false);
        G4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G4.add(G4ship);
        G4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G4);
        G4.setBounds(180, 360, 60, 60);

        D4.setBackground(new java.awt.Color(255, 255, 240));
        D4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D4.setMinimumSize(new java.awt.Dimension(60, 60));
        D4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D4MouseExited(evt);
            }
        });
        D4.setLayout(null);

        D4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D4ship.setFocusable(false);
        D4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D4.add(D4ship);
        D4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D4);
        D4.setBounds(180, 180, 60, 60);

        D5.setBackground(new java.awt.Color(255, 255, 240));
        D5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D5.setMinimumSize(new java.awt.Dimension(60, 60));
        D5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D5MouseExited(evt);
            }
        });
        D5.setLayout(null);

        D5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D5ship.setFocusable(false);
        D5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D5.add(D5ship);
        D5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D5);
        D5.setBounds(240, 180, 60, 60);

        D6.setBackground(new java.awt.Color(255, 255, 240));
        D6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D6.setMinimumSize(new java.awt.Dimension(60, 60));
        D6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D6MouseExited(evt);
            }
        });
        D6.setLayout(null);

        D6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D6ship.setFocusable(false);
        D6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D6.add(D6ship);
        D6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D6);
        D6.setBounds(300, 180, 60, 60);

        D7.setBackground(new java.awt.Color(255, 255, 240));
        D7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D7.setMinimumSize(new java.awt.Dimension(60, 60));
        D7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D7MouseExited(evt);
            }
        });
        D7.setLayout(null);

        D7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D7ship.setFocusable(false);
        D7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D7.add(D7ship);
        D7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D7);
        D7.setBounds(360, 180, 60, 60);

        D8.setBackground(new java.awt.Color(255, 255, 240));
        D8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D8.setMinimumSize(new java.awt.Dimension(60, 60));
        D8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D8MouseExited(evt);
            }
        });
        D8.setLayout(null);

        D8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D8ship.setFocusable(false);
        D8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D8.add(D8ship);
        D8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D8);
        D8.setBounds(420, 180, 60, 60);

        D9.setBackground(new java.awt.Color(255, 255, 240));
        D9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D9.setMinimumSize(new java.awt.Dimension(60, 60));
        D9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D9MouseExited(evt);
            }
        });
        D9.setLayout(null);

        D9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D9ship.setFocusable(false);
        D9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D9.add(D9ship);
        D9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D9);
        D9.setBounds(480, 180, 60, 60);

        D10.setBackground(new java.awt.Color(255, 255, 240));
        D10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        D10.setMinimumSize(new java.awt.Dimension(60, 60));
        D10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                D10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                D10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                D10MouseExited(evt);
            }
        });
        D10.setLayout(null);

        D10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        D10ship.setFocusable(false);
        D10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        D10.add(D10ship);
        D10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(D10);
        D10.setBounds(540, 180, 60, 60);

        C10.setBackground(new java.awt.Color(255, 255, 240));
        C10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C10.setMinimumSize(new java.awt.Dimension(60, 60));
        C10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C10MouseExited(evt);
            }
        });
        C10.setLayout(null);

        C10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C10ship.setFocusable(false);
        C10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C10.add(C10ship);
        C10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C10);
        C10.setBounds(540, 120, 60, 60);

        B10.setBackground(new java.awt.Color(255, 255, 240));
        B10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B10.setMinimumSize(new java.awt.Dimension(60, 60));
        B10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B10MouseExited(evt);
            }
        });
        B10.setLayout(null);

        B10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B10ship.setFocusable(false);
        B10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B10.add(B10ship);
        B10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B10);
        B10.setBounds(540, 60, 60, 60);

        B9.setBackground(new java.awt.Color(255, 255, 240));
        B9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B9.setMinimumSize(new java.awt.Dimension(60, 60));
        B9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B9MouseExited(evt);
            }
        });
        B9.setLayout(null);

        B9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B9ship.setFocusable(false);
        B9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B9.add(B9ship);
        B9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B9);
        B9.setBounds(480, 60, 60, 60);

        C9.setBackground(new java.awt.Color(255, 255, 240));
        C9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C9.setMinimumSize(new java.awt.Dimension(60, 60));
        C9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C9MouseExited(evt);
            }
        });
        C9.setLayout(null);

        C9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C9ship.setFocusable(false);
        C9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C9.add(C9ship);
        C9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C9);
        C9.setBounds(480, 120, 60, 60);

        B7.setBackground(new java.awt.Color(255, 255, 240));
        B7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B7.setMinimumSize(new java.awt.Dimension(60, 60));
        B7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B7MouseExited(evt);
            }
        });
        B7.setLayout(null);

        B7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B7ship.setFocusable(false);
        B7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B7.add(B7ship);
        B7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B7);
        B7.setBounds(360, 60, 60, 60);

        B8.setBackground(new java.awt.Color(255, 255, 240));
        B8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B8.setMinimumSize(new java.awt.Dimension(60, 60));
        B8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B8MouseExited(evt);
            }
        });
        B8.setLayout(null);

        B8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B8ship.setFocusable(false);
        B8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B8.add(B8ship);
        B8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B8);
        B8.setBounds(420, 60, 60, 60);

        E4.setBackground(new java.awt.Color(255, 255, 240));
        E4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        E4.setMinimumSize(new java.awt.Dimension(60, 60));
        E4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                E4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                E4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                E4MouseExited(evt);
            }
        });
        E4.setLayout(null);

        E4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        E4ship.setFocusable(false);
        E4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        E4.add(E4ship);
        E4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(E4);
        E4.setBounds(180, 240, 60, 60);

        C7.setBackground(new java.awt.Color(255, 255, 240));
        C7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C7.setMinimumSize(new java.awt.Dimension(60, 60));
        C7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C7MouseExited(evt);
            }
        });
        C7.setLayout(null);

        C7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C7ship.setFocusable(false);
        C7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C7.add(C7ship);
        C7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C7);
        C7.setBounds(360, 120, 60, 60);

        B6.setBackground(new java.awt.Color(255, 255, 240));
        B6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B6.setMinimumSize(new java.awt.Dimension(60, 60));
        B6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B6MouseExited(evt);
            }
        });
        B6.setLayout(null);

        B6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B6ship.setFocusable(false);
        B6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B6.add(B6ship);
        B6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B6);
        B6.setBounds(300, 60, 60, 60);

        C6.setBackground(new java.awt.Color(255, 255, 240));
        C6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C6.setMinimumSize(new java.awt.Dimension(60, 60));
        C6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C6MouseExited(evt);
            }
        });
        C6.setLayout(null);

        C6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C6ship.setFocusable(false);
        C6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C6.add(C6ship);
        C6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C6);
        C6.setBounds(300, 120, 60, 60);

        B5.setBackground(new java.awt.Color(255, 255, 240));
        B5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B5.setMinimumSize(new java.awt.Dimension(60, 60));
        B5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B5MouseExited(evt);
            }
        });
        B5.setLayout(null);

        B5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B5ship.setFocusable(false);
        B5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B5.add(B5ship);
        B5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B5);
        B5.setBounds(240, 60, 60, 60);

        C8.setBackground(new java.awt.Color(255, 255, 240));
        C8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C8.setMinimumSize(new java.awt.Dimension(60, 60));
        C8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C8MouseExited(evt);
            }
        });
        C8.setLayout(null);

        C8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C8ship.setFocusable(false);
        C8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C8.add(C8ship);
        C8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C8);
        C8.setBounds(420, 120, 60, 60);

        C4.setBackground(new java.awt.Color(255, 255, 240));
        C4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        C4.setMinimumSize(new java.awt.Dimension(60, 60));
        C4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                C4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                C4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                C4MouseExited(evt);
            }
        });
        C4.setLayout(null);

        C4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        C4ship.setFocusable(false);
        C4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        C4.add(C4ship);
        C4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(C4);
        C4.setBounds(180, 120, 60, 60);

        B4.setBackground(new java.awt.Color(255, 255, 240));
        B4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B4.setMinimumSize(new java.awt.Dimension(60, 60));
        B4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B4MouseExited(evt);
            }
        });
        B4.setLayout(null);

        B4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B4ship.setFocusable(false);
        B4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B4.add(B4ship);
        B4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B4);
        B4.setBounds(180, 60, 60, 60);

        H4.setBackground(new java.awt.Color(255, 255, 240));
        H4.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H4.setMinimumSize(new java.awt.Dimension(60, 60));
        H4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H4MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H4MouseExited(evt);
            }
        });
        H4.setLayout(null);

        H4ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H4ship.setFocusable(false);
        H4ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H4.add(H4ship);
        H4ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H4);
        H4.setBounds(180, 420, 60, 60);

        G6.setBackground(new java.awt.Color(255, 255, 240));
        G6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G6.setMinimumSize(new java.awt.Dimension(60, 60));
        G6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G6MouseExited(evt);
            }
        });
        G6.setLayout(null);

        G6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G6ship.setFocusable(false);
        G6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G6.add(G6ship);
        G6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G6);
        G6.setBounds(300, 360, 60, 60);

        G5.setBackground(new java.awt.Color(255, 255, 240));
        G5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G5.setMinimumSize(new java.awt.Dimension(60, 60));
        G5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G5MouseExited(evt);
            }
        });
        G5.setLayout(null);

        G5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G5ship.setFocusable(false);
        G5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G5.add(G5ship);
        G5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G5);
        G5.setBounds(240, 360, 60, 60);

        H5.setBackground(new java.awt.Color(255, 255, 240));
        H5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H5.setMinimumSize(new java.awt.Dimension(60, 60));
        H5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H5MouseExited(evt);
            }
        });
        H5.setLayout(null);

        H5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H5ship.setFocusable(false);
        H5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H5.add(H5ship);
        H5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H5);
        H5.setBounds(240, 420, 60, 60);

        F6.setBackground(new java.awt.Color(255, 255, 240));
        F6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        F6.setMinimumSize(new java.awt.Dimension(60, 60));
        F6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                F6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                F6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                F6MouseExited(evt);
            }
        });
        F6.setLayout(null);

        F6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        F6ship.setFocusable(false);
        F6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        F6.add(F6ship);
        F6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(F6);
        F6.setBounds(300, 300, 60, 60);

        I6.setBackground(new java.awt.Color(255, 255, 240));
        I6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I6.setMinimumSize(new java.awt.Dimension(60, 60));
        I6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I6MouseExited(evt);
            }
        });
        I6.setLayout(null);

        I6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I6ship.setFocusable(false);
        I6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I6.add(I6ship);
        I6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I6);
        I6.setBounds(300, 480, 60, 60);

        I5.setBackground(new java.awt.Color(255, 255, 240));
        I5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I5.setMinimumSize(new java.awt.Dimension(60, 60));
        I5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I5MouseExited(evt);
            }
        });
        I5.setLayout(null);

        I5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I5ship.setFocusable(false);
        I5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I5.add(I5ship);
        I5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I5);
        I5.setBounds(240, 480, 60, 60);

        L5.setBackground(new java.awt.Color(255, 255, 240));
        L5.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L5.setMinimumSize(new java.awt.Dimension(60, 60));
        L5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L5MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L5MouseExited(evt);
            }
        });
        L5.setLayout(null);

        L5ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L5ship.setFocusable(false);
        L5ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L5.add(L5ship);
        L5ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L5);
        L5.setBounds(240, 540, 60, 60);

        L6.setBackground(new java.awt.Color(255, 255, 240));
        L6.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L6.setMinimumSize(new java.awt.Dimension(60, 60));
        L6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L6MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L6MouseExited(evt);
            }
        });
        L6.setLayout(null);

        L6ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L6ship.setFocusable(false);
        L6ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L6.add(L6ship);
        L6ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L6);
        L6.setBounds(300, 540, 60, 60);

        L7.setBackground(new java.awt.Color(255, 255, 240));
        L7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L7.setMinimumSize(new java.awt.Dimension(60, 60));
        L7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L7MouseExited(evt);
            }
        });
        L7.setLayout(null);

        L7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L7ship.setFocusable(false);
        L7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L7.add(L7ship);
        L7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L7);
        L7.setBounds(360, 540, 60, 60);

        I7.setBackground(new java.awt.Color(255, 255, 240));
        I7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I7.setMinimumSize(new java.awt.Dimension(60, 60));
        I7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I7MouseExited(evt);
            }
        });
        I7.setLayout(null);

        I7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I7ship.setFocusable(false);
        I7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I7.add(I7ship);
        I7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I7);
        I7.setBounds(360, 480, 60, 60);

        H7.setBackground(new java.awt.Color(255, 255, 240));
        H7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H7.setMinimumSize(new java.awt.Dimension(60, 60));
        H7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H7MouseExited(evt);
            }
        });
        H7.setLayout(null);

        H7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H7ship.setFocusable(false);
        H7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H7.add(H7ship);
        H7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H7);
        H7.setBounds(360, 420, 60, 60);

        G7.setBackground(new java.awt.Color(255, 255, 240));
        G7.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G7.setMinimumSize(new java.awt.Dimension(60, 60));
        G7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G7MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G7MouseExited(evt);
            }
        });
        G7.setLayout(null);

        G7ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G7ship.setFocusable(false);
        G7ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G7.add(G7ship);
        G7ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G7);
        G7.setBounds(360, 360, 60, 60);

        G8.setBackground(new java.awt.Color(255, 255, 240));
        G8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G8.setMinimumSize(new java.awt.Dimension(60, 60));
        G8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G8MouseExited(evt);
            }
        });
        G8.setLayout(null);

        G8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G8ship.setFocusable(false);
        G8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G8.add(G8ship);
        G8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G8);
        G8.setBounds(420, 360, 60, 60);

        H8.setBackground(new java.awt.Color(255, 255, 240));
        H8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H8.setMinimumSize(new java.awt.Dimension(60, 60));
        H8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H8MouseExited(evt);
            }
        });
        H8.setLayout(null);

        H8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H8ship.setFocusable(false);
        H8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H8.add(H8ship);
        H8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H8);
        H8.setBounds(420, 420, 60, 60);

        I8.setBackground(new java.awt.Color(255, 255, 240));
        I8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I8.setMinimumSize(new java.awt.Dimension(60, 60));
        I8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I8MouseExited(evt);
            }
        });
        I8.setLayout(null);

        I8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I8ship.setFocusable(false);
        I8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I8.add(I8ship);
        I8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I8);
        I8.setBounds(420, 480, 60, 60);

        L8.setBackground(new java.awt.Color(255, 255, 240));
        L8.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L8.setMinimumSize(new java.awt.Dimension(60, 60));
        L8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L8MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L8MouseExited(evt);
            }
        });
        L8.setLayout(null);

        L8ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L8ship.setFocusable(false);
        L8ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L8.add(L8ship);
        L8ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L8);
        L8.setBounds(420, 540, 60, 60);

        L9.setBackground(new java.awt.Color(255, 255, 240));
        L9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L9.setMinimumSize(new java.awt.Dimension(60, 60));
        L9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L9MouseExited(evt);
            }
        });
        L9.setLayout(null);

        L9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L9ship.setFocusable(false);
        L9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L9.add(L9ship);
        L9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L9);
        L9.setBounds(480, 540, 60, 60);

        L10.setBackground(new java.awt.Color(255, 255, 240));
        L10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        L10.setMinimumSize(new java.awt.Dimension(60, 60));
        L10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                L10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                L10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                L10MouseExited(evt);
            }
        });
        L10.setLayout(null);

        L10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        L10ship.setFocusable(false);
        L10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        L10.add(L10ship);
        L10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(L10);
        L10.setBounds(540, 540, 60, 60);

        I10.setBackground(new java.awt.Color(255, 255, 240));
        I10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I10.setMinimumSize(new java.awt.Dimension(60, 60));
        I10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I10MouseExited(evt);
            }
        });
        I10.setLayout(null);

        I10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I10ship.setFocusable(false);
        I10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I10.add(I10ship);
        I10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I10);
        I10.setBounds(540, 480, 60, 60);

        H10.setBackground(new java.awt.Color(255, 255, 240));
        H10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H10.setMinimumSize(new java.awt.Dimension(60, 60));
        H10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H10MouseExited(evt);
            }
        });
        H10.setLayout(null);

        H10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H10ship.setFocusable(false);
        H10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H10.add(H10ship);
        H10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H10);
        H10.setBounds(540, 420, 60, 60);

        G10.setBackground(new java.awt.Color(255, 255, 240));
        G10.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G10.setMinimumSize(new java.awt.Dimension(60, 60));
        G10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G10MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G10MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G10MouseExited(evt);
            }
        });
        G10.setLayout(null);

        G10ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G10ship.setFocusable(false);
        G10ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G10.add(G10ship);
        G10ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G10);
        G10.setBounds(540, 360, 60, 60);

        G9.setBackground(new java.awt.Color(255, 255, 240));
        G9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        G9.setMinimumSize(new java.awt.Dimension(60, 60));
        G9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                G9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                G9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                G9MouseExited(evt);
            }
        });
        G9.setLayout(null);

        G9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        G9ship.setFocusable(false);
        G9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        G9.add(G9ship);
        G9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(G9);
        G9.setBounds(480, 360, 60, 60);

        H9.setBackground(new java.awt.Color(255, 255, 240));
        H9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        H9.setMinimumSize(new java.awt.Dimension(60, 60));
        H9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                H9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                H9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                H9MouseExited(evt);
            }
        });
        H9.setLayout(null);

        H9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        H9ship.setFocusable(false);
        H9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        H9.add(H9ship);
        H9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(H9);
        H9.setBounds(480, 420, 60, 60);

        I9.setBackground(new java.awt.Color(255, 255, 240));
        I9.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        I9.setMinimumSize(new java.awt.Dimension(60, 60));
        I9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                I9MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                I9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                I9MouseExited(evt);
            }
        });
        I9.setLayout(null);

        I9ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        I9ship.setFocusable(false);
        I9ship.setPreferredSize(new java.awt.Dimension(60, 60));
        I9.add(I9ship);
        I9ship.setBounds(0, 0, 52, 51);

        jPanel1.add(I9);
        I9.setBounds(480, 480, 60, 60);

        B2.setBackground(new java.awt.Color(255, 255, 240));
        B2.setBorder(javax.swing.BorderFactory.createEtchedBorder(javax.swing.border.EtchedBorder.RAISED, java.awt.Color.gray, java.awt.Color.lightGray));
        B2.setMinimumSize(new java.awt.Dimension(60, 60));
        B2.setPreferredSize(new java.awt.Dimension(60, 60));
        B2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                B2MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                B2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                B2MouseExited(evt);
            }
        });
        B2.setLayout(null);

        B2ship.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ship.png"))); // NOI18N
        B2ship.setFocusable(false);
        B2ship.setPreferredSize(new java.awt.Dimension(60, 60));
        B2.add(B2ship);
        B2ship.setBounds(0, 0, 52, 51);

        jPanel1.add(B2);
        B2.setBounds(60, 60, 60, 60);

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 110, -1, -1));

        jPanel105.setBackground(new java.awt.Color(0, 49, 83));
        jPanel105.setLayout(null);

        label21.setAlignment(java.awt.Label.CENTER);
        label21.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label21.setForeground(new java.awt.Color(255, 255, 240));
        label21.setMinimumSize(new java.awt.Dimension(15, 22));
        label21.setPreferredSize(new java.awt.Dimension(35, 35));
        label21.setText("C");
        jPanel105.add(label21);
        label21.setBounds(0, 132, 35, 35);

        label23.setAlignment(java.awt.Label.CENTER);
        label23.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label23.setForeground(new java.awt.Color(255, 255, 240));
        label23.setMinimumSize(new java.awt.Dimension(15, 22));
        label23.setPreferredSize(new java.awt.Dimension(35, 35));
        label23.setText("B");
        jPanel105.add(label23);
        label23.setBounds(0, 72, 35, 35);

        label24.setAlignment(java.awt.Label.CENTER);
        label24.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label24.setForeground(new java.awt.Color(255, 255, 240));
        label24.setMinimumSize(new java.awt.Dimension(15, 22));
        label24.setPreferredSize(new java.awt.Dimension(35, 35));
        label24.setText("L");
        jPanel105.add(label24);
        label24.setBounds(0, 552, 35, 35);

        label25.setAlignment(java.awt.Label.CENTER);
        label25.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label25.setForeground(new java.awt.Color(255, 255, 240));
        label25.setMinimumSize(new java.awt.Dimension(15, 22));
        label25.setPreferredSize(new java.awt.Dimension(35, 35));
        label25.setText("D");
        jPanel105.add(label25);
        label25.setBounds(0, 192, 35, 35);

        label26.setAlignment(java.awt.Label.CENTER);
        label26.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label26.setForeground(new java.awt.Color(255, 255, 240));
        label26.setMinimumSize(new java.awt.Dimension(15, 22));
        label26.setPreferredSize(new java.awt.Dimension(35, 35));
        label26.setText("E");
        jPanel105.add(label26);
        label26.setBounds(0, 252, 35, 35);

        label27.setAlignment(java.awt.Label.CENTER);
        label27.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label27.setForeground(new java.awt.Color(255, 255, 240));
        label27.setMinimumSize(new java.awt.Dimension(15, 22));
        label27.setPreferredSize(new java.awt.Dimension(35, 35));
        label27.setText("F");
        jPanel105.add(label27);
        label27.setBounds(0, 312, 35, 35);

        label28.setAlignment(java.awt.Label.CENTER);
        label28.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label28.setForeground(new java.awt.Color(255, 255, 240));
        label28.setMinimumSize(new java.awt.Dimension(15, 22));
        label28.setPreferredSize(new java.awt.Dimension(35, 35));
        label28.setText("G");
        jPanel105.add(label28);
        label28.setBounds(0, 372, 35, 35);

        label29.setAlignment(java.awt.Label.CENTER);
        label29.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label29.setForeground(new java.awt.Color(255, 255, 240));
        label29.setMinimumSize(new java.awt.Dimension(15, 22));
        label29.setPreferredSize(new java.awt.Dimension(35, 35));
        label29.setText("H");
        jPanel105.add(label29);
        label29.setBounds(0, 432, 35, 35);

        label30.setAlignment(java.awt.Label.CENTER);
        label30.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label30.setForeground(new java.awt.Color(255, 255, 240));
        label30.setMinimumSize(new java.awt.Dimension(15, 22));
        label30.setPreferredSize(new java.awt.Dimension(35, 35));
        label30.setText("I");
        jPanel105.add(label30);
        label30.setBounds(0, 492, 35, 35);

        label31.setAlignment(java.awt.Label.CENTER);
        label31.setFont(new java.awt.Font("Georgia", 1, 18)); // NOI18N
        label31.setForeground(new java.awt.Color(255, 255, 240));
        label31.setMinimumSize(new java.awt.Dimension(15, 22));
        label31.setPreferredSize(new java.awt.Dimension(35, 35));
        label31.setText("A");
        jPanel105.add(label31);
        label31.setBounds(0, 12, 35, 35);

        jPanel2.add(jPanel105, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 35, 600));

        conteggio.setBackground(new java.awt.Color(0, 49, 83));
        conteggio.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        conteggio.setForeground(new java.awt.Color(0, 49, 83));
        conteggio.setText("14");
        jPanel2.add(conteggio, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, -1, -1));

        jLabel5.setBackground(new java.awt.Color(0, 49, 83));
        jLabel5.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 49, 83));
        jLabel5.setText("NAVI RIMASTE:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, -1, -1));

        jLabel6.setBackground(new java.awt.Color(0, 49, 83));
        jLabel6.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 49, 83));
        jLabel6.setText("TEMPO RIMANENTE:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));

        tempotimer.setBackground(new java.awt.Color(0, 49, 83));
        tempotimer.setFont(new java.awt.Font("Verdana", 1, 20)); // NOI18N
        tempotimer.setForeground(new java.awt.Color(0, 49, 83));
        tempotimer.setText("60s");
        jPanel2.add(tempotimer, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 760, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void A1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A1MouseClicked
        A1ship.setVisible(true);
        naviPosizionate.add("A1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));

    }//GEN-LAST:event_A1MouseClicked
    private void A1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A1MouseEntered
        A1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A1MouseEntered
    private void A1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A1MouseExited
        A1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A1MouseExited
    private void A2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A2MouseClicked
        A2ship.setVisible(true);
        naviPosizionate.add("A2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));

    }//GEN-LAST:event_A2MouseClicked
    private void A2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A2MouseEntered
        // TODO add your handling code here:
        A2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A2MouseEntered
    private void A2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A2MouseExited
        // TODO add your handling code here:
        A2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A2MouseExited
    private void A3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A3MouseClicked
        // TODO add your handling code here:
        A3ship.setVisible(true);
        naviPosizionate.add("A3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));

    }//GEN-LAST:event_A3MouseClicked
    private void A4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A4MouseClicked
        // TODO add your handling code here:
        A4ship.setVisible(true);
        naviPosizionate.add("A4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_A4MouseClicked
    private void A5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A5MouseClicked
        // TODO add your handling code here:
        A5ship.setVisible(true);
        naviPosizionate.add("A5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_A5MouseClicked
    private void A6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A6MouseClicked
        // TODO add your handling code here:
        A6ship.setVisible(true);
        naviPosizionate.add("A6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_A6MouseClicked
    private void A7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A7MouseClicked
        // TODO add your handling code here:
        A7ship.setVisible(true);
        naviPosizionate.add("A7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_A7MouseClicked
    private void A8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A8MouseClicked
        // TODO add your handling code here:
        A8ship.setVisible(true);
        naviPosizionate.add("A8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_A8MouseClicked
    private void A9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A9MouseClicked
        // TODO add your handling code here:
        A9ship.setVisible(true);
        naviPosizionate.add("A9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_A9MouseClicked
    private void A10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A10MouseClicked
        // TODO add your handling code here:
        A10ship.setVisible(true);
        naviPosizionate.add("A10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_A10MouseClicked
    private void B1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B1MouseClicked
        // TODO add your handling code here:
        B1ship.setVisible(true);
        naviPosizionate.add("B1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B1MouseClicked
    private void B3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B3MouseClicked
        // TODO add your handling code here:
        B3ship.setVisible(true);
        naviPosizionate.add("B3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B3MouseClicked
    private void B4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B4MouseClicked
        // TODO add your handling code here:
        B4ship.setVisible(true);
        naviPosizionate.add("B4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B4MouseClicked
    private void B5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B5MouseClicked
        // TODO add your handling code here:
        B5ship.setVisible(true);
        naviPosizionate.add("B5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B5MouseClicked
    private void B6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B6MouseClicked
        // TODO add your handling code here:
        B6ship.setVisible(true);
        naviPosizionate.add("B6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B6MouseClicked
    private void B7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B7MouseClicked
        // TODO add your handling code here:
        B7ship.setVisible(true);
        naviPosizionate.add("B7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B7MouseClicked
    private void B8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B8MouseClicked
        // TODO add your handling code here:
        B8ship.setVisible(true);
        naviPosizionate.add("B8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B8MouseClicked
    private void B9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B9MouseClicked
        // TODO add your handling code here:
        B9ship.setVisible(true);
        naviPosizionate.add("B9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B9MouseClicked
    private void B10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B10MouseClicked
        // TODO add your handling code here:
        B10ship.setVisible(true);
        naviPosizionate.add("B10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_B10MouseClicked
    private void C1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C1MouseClicked
        // TODO add your handling code here:
        C1ship.setVisible(true);
        naviPosizionate.add("C1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C1MouseClicked
    private void C2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C2MouseClicked
        // TODO add your handling code here:
        C2ship.setVisible(true);
        naviPosizionate.add("C2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C2MouseClicked
    private void C3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C3MouseClicked
        // TODO add your handling code here:
        C3ship.setVisible(true);
        naviPosizionate.add("C3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C3MouseClicked
    private void C4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C4MouseClicked
        // TODO add your handling code here:
        C4ship.setVisible(true);
        naviPosizionate.add("C4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C4MouseClicked
    private void C5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C5MouseClicked
        // TODO add your handling code here:
        C5ship.setVisible(true);
        naviPosizionate.add("C5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C5MouseClicked
    private void C6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C6MouseClicked
        // TODO add your handling code here:
        C6ship.setVisible(true);
        naviPosizionate.add("C6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C6MouseClicked
    private void C7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C7MouseClicked
        // TODO add your handling code here:
        C7ship.setVisible(true);
        naviPosizionate.add("C7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C7MouseClicked
    private void C8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C8MouseClicked
        // TODO add your handling code here:
        C8ship.setVisible(true);
        naviPosizionate.add("C8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C8MouseClicked
    private void C9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C9MouseClicked
        // TODO add your handling code here:
        C9ship.setVisible(true);
        naviPosizionate.add("C9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C9MouseClicked
    private void C10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C10MouseClicked
        // TODO add your handling code here:
        C10ship.setVisible(true);
        naviPosizionate.add("C10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_C10MouseClicked
    private void D1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D1MouseClicked
        // TODO add your handling code here:
        D1ship.setVisible(true);
        naviPosizionate.add("D1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D1MouseClicked
    private void D2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D2MouseClicked
        // TODO add your handling code here:
        D2ship.setVisible(true);
        naviPosizionate.add("D2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D2MouseClicked
    private void D3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D3MouseClicked
        // TODO add your handling code here:
        D3ship.setVisible(true);
        naviPosizionate.add("D3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D3MouseClicked
    private void D4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D4MouseClicked
        // TODO add your handling code here:
        D4ship.setVisible(true);
        naviPosizionate.add("D4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D4MouseClicked
    private void D5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D5MouseClicked
        // TODO add your handling code here:
        D5ship.setVisible(true);
        naviPosizionate.add("D5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));

    }//GEN-LAST:event_D5MouseClicked
    private void D6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D6MouseClicked
        // TODO add your handling code here:
        D6ship.setVisible(true);
        naviPosizionate.add("D6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D6MouseClicked
    private void D7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D7MouseClicked
        // TODO add your handling code here:
        D7ship.setVisible(true);
        naviPosizionate.add("D7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D7MouseClicked
    private void D8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D8MouseClicked
        // TODO add your handling code here:
        D8ship.setVisible(true);
        naviPosizionate.add("D8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D8MouseClicked
    private void D9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D9MouseClicked
        // TODO add your handling code here:
        D9ship.setVisible(true);
        naviPosizionate.add("D9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D9MouseClicked
    private void D10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D10MouseClicked
        // TODO add your handling code here:
        D10ship.setVisible(true);
        naviPosizionate.add("D10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_D10MouseClicked
    private void E1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E1MouseClicked
        // TODO add your handling code here:
        E1ship.setVisible(true);
        naviPosizionate.add("E1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E1MouseClicked
    private void E2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E2MouseClicked
        // TODO add your handling code here:
        E2ship.setVisible(true);
        naviPosizionate.add("E2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E2MouseClicked
    private void E3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E3MouseClicked
        // TODO add your handling code here:
        E3ship.setVisible(true);
        naviPosizionate.add("E3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E3MouseClicked
    private void E4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E4MouseClicked
        // TODO add your handling code here:
        E4ship.setVisible(true);
        naviPosizionate.add("E4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E4MouseClicked
    private void E5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E5MouseClicked
        // TODO add your handling code here:
        E5ship.setVisible(true);
        naviPosizionate.add("E5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E5MouseClicked
    private void E6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E6MouseClicked
        // TODO add your handling code here:
        E6ship.setVisible(true);
        naviPosizionate.add("E6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E6MouseClicked
    private void E7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E7MouseClicked
        // TODO add your handling code here:
        E7ship.setVisible(true);
        naviPosizionate.add("E7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E7MouseClicked
    private void E8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E8MouseClicked
        // TODO add your handling code here:
        E8ship.setVisible(true);
        naviPosizionate.add("E8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E8MouseClicked
    private void E9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E9MouseClicked
        // TODO add your handling code here:
        E9ship.setVisible(true);
        naviPosizionate.add("E9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E9MouseClicked
    private void E10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E10MouseClicked
        // TODO add your handling code here:
        E10ship.setVisible(true);
        naviPosizionate.add("E10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_E10MouseClicked
    private void F1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F1MouseClicked
        // TODO add your handling code here:
        F1ship.setVisible(true);
        naviPosizionate.add("F1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F1MouseClicked
    private void F2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F2MouseClicked
        // TODO add your handling code here:
        F2ship.setVisible(true);
        naviPosizionate.add("F2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F2MouseClicked
    private void F3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F3MouseClicked
        // TODO add your handling code here:
        F3ship.setVisible(true);
        naviPosizionate.add("F3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F3MouseClicked
    private void F4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F4MouseClicked
        // TODO add your handling code here:
        F4ship.setVisible(true);
        naviPosizionate.add("F4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F4MouseClicked
    private void F5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F5MouseClicked
        // TODO add your handling code here:
        F5ship.setVisible(true);
        naviPosizionate.add("F5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F5MouseClicked
    private void F6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F6MouseClicked
        // TODO add your handling code here:
        F6ship.setVisible(true);
        naviPosizionate.add("F6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F6MouseClicked
    private void F7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F7MouseClicked
        // TODO add your handling code here:
        F7ship.setVisible(true);
        naviPosizionate.add("F7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F7MouseClicked
    private void F8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F8MouseClicked
        // TODO add your handling code here:
        F8ship.setVisible(true);
        naviPosizionate.add("F8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F8MouseClicked
    private void F9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F9MouseClicked
        // TODO add your handling code here:
        F9ship.setVisible(true);
        naviPosizionate.add("F9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F9MouseClicked
    private void F10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F10MouseClicked
        // TODO add your handling code here:
        F10ship.setVisible(true);
        naviPosizionate.add("F10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_F10MouseClicked
    private void G1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G1MouseClicked
        // TODO add your handling code here:
        G1ship.setVisible(true);
        naviPosizionate.add("G1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G1MouseClicked
    private void G2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G2MouseClicked
        // TODO add your handling code here:
        G2ship.setVisible(true);
        naviPosizionate.add("G2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G2MouseClicked
    private void G3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G3MouseClicked
        // TODO add your handling code here:
        G3ship.setVisible(true);
        naviPosizionate.add("G3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G3MouseClicked
    private void G4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G4MouseClicked
        // TODO add your handling code here:
        G4ship.setVisible(true);
        naviPosizionate.add("G4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G4MouseClicked
    private void G5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G5MouseClicked
        // TODO add your handling code here:
        G5ship.setVisible(true);
        naviPosizionate.add("G5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G5MouseClicked
    private void G6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G6MouseClicked
        // TODO add your handling code here:
        G6ship.setVisible(true);
        naviPosizionate.add("G6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G6MouseClicked
    private void G7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G7MouseClicked
        // TODO add your handling code here:
        G7ship.setVisible(true);
        naviPosizionate.add("G7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G7MouseClicked
    private void G8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G8MouseClicked
        // TODO add your handling code here:
        G8ship.setVisible(true);
        naviPosizionate.add("G8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G8MouseClicked
    private void G9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G9MouseClicked
        // TODO add your handling code here:
        G9ship.setVisible(true);
        naviPosizionate.add("G9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G9MouseClicked
    private void G10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G10MouseClicked
        // TODO add your handling code here:
        G10ship.setVisible(true);
        naviPosizionate.add("G10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_G10MouseClicked
    private void H1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H1MouseClicked
        // TODO add your handling code here:
        H1ship.setVisible(true);
        naviPosizionate.add("H1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H1MouseClicked
    private void H2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H2MouseClicked
        // TODO add your handling code here:
        H2ship.setVisible(true);
        naviPosizionate.add("H2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H2MouseClicked
    private void H3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H3MouseClicked
        // TODO add your handling code here:
        H3ship.setVisible(true);
        naviPosizionate.add("H3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H3MouseClicked
    private void H4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H4MouseClicked
        // TODO add your handling code here:
        H4ship.setVisible(true);
        naviPosizionate.add("H4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H4MouseClicked
    private void H5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H5MouseClicked
        // TODO add your handling code here:
        H5ship.setVisible(true);
        naviPosizionate.add("H5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H5MouseClicked
    private void H6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H6MouseClicked
        // TODO add your handling code here:
        H6ship.setVisible(true);
        naviPosizionate.add("H6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H6MouseClicked
    private void H7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H7MouseClicked
        // TODO add your handling code here:
        H7ship.setVisible(true);
        naviPosizionate.add("H7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H7MouseClicked
    private void H8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H8MouseClicked
        // TODO add your handling code here:
        H8ship.setVisible(true);
        naviPosizionate.add("H8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H8MouseClicked
    private void H9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H9MouseClicked
        // TODO add your handling code here:
        H9ship.setVisible(true);
        naviPosizionate.add("H9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H9MouseClicked
    private void H10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H10MouseClicked
        // TODO add your handling code here:
        H10ship.setVisible(true);
        naviPosizionate.add("H10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_H10MouseClicked
    private void I1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I1MouseClicked
        // TODO add your handling code here:
        I1ship.setVisible(true);
        naviPosizionate.add("I1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I1MouseClicked
    private void I2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I2MouseClicked
        // TODO add your handling code here:
        I2ship.setVisible(true);
        naviPosizionate.add("I2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I2MouseClicked
    private void I3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I3MouseClicked
        // TODO add your handling code here:
        I3ship.setVisible(true);
        naviPosizionate.add("I3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I3MouseClicked
    private void I4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I4MouseClicked
        // TODO add your handling code here:
        I4ship.setVisible(true);
        naviPosizionate.add("I4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I4MouseClicked
    private void I5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I5MouseClicked
        // TODO add your handling code here:
        I5ship.setVisible(true);
        naviPosizionate.add("I5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I5MouseClicked
    private void I6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I6MouseClicked
        // TODO add your handling code here:
        I6ship.setVisible(true);
        naviPosizionate.add("I6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I6MouseClicked
    private void I8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I8MouseClicked
        // TODO add your handling code here:
        I8ship.setVisible(true);
        naviPosizionate.add("I8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I8MouseClicked
    private void I9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I9MouseClicked
        // TODO add your handling code here:
        I9ship.setVisible(true);
        naviPosizionate.add("I9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I9MouseClicked
    private void I10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I10MouseClicked
        // TODO add your handling code here:
        I10ship.setVisible(true);
        naviPosizionate.add("I10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_I10MouseClicked
    private void L1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L1MouseClicked
        // TODO add your handling code here:
        L1ship.setVisible(true);
        naviPosizionate.add("L1;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L1MouseClicked
    private void L2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L2MouseClicked
        // TODO add your handling code here:
        L2ship.setVisible(true);
        naviPosizionate.add("L2;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L2MouseClicked
    private void L3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L3MouseClicked
        // TODO add your handling code here:
        L3ship.setVisible(true);
        naviPosizionate.add("L3;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L3MouseClicked
    private void L4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L4MouseClicked
        // TODO add your handling code here:
        L4ship.setVisible(true);
        naviPosizionate.add("L4;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L4MouseClicked
    private void L5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L5MouseClicked
        // TODO add your handling code here:
        L5ship.setVisible(true);
        naviPosizionate.add("L5;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L5MouseClicked
    private void L6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L6MouseClicked
        // TODO add your handling code here:
        L6ship.setVisible(true);
        naviPosizionate.add("L6;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L6MouseClicked
    private void L7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L7MouseClicked
        // TODO add your handling code here:
        L7ship.setVisible(true);
        naviPosizionate.add("L7;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L7MouseClicked
    private void L8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L8MouseClicked
        // TODO add your handling code here:
        L8ship.setVisible(true);
        naviPosizionate.add("L8;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));

    }//GEN-LAST:event_L8MouseClicked
    private void L9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L9MouseClicked
        // TODO add your handling code here:
        L9ship.setVisible(true);
        naviPosizionate.add("L9;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L9MouseClicked
    private void L10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L10MouseClicked
        // TODO add your handling code here:
        L10ship.setVisible(true);
        naviPosizionate.add("L10;");
        if (ContatoreNavi == 1) {
            FinePosizionamento();
        }
        ContatoreNavi--;
        conteggio.setText(String.valueOf(ContatoreNavi));
    }//GEN-LAST:event_L10MouseClicked
    private void I7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I7MouseClicked
        // TODO add your handling code here:
        I7ship.setVisible(true);
    }//GEN-LAST:event_I7MouseClicked
    private void A3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A3MouseEntered
        // TODO add your handling code here:
        A3.setBackground(new Color(236, 241, 199));

    }//GEN-LAST:event_A3MouseEntered
    private void A4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A4MouseEntered
        // TODO add your handling code here:
        A4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A4MouseEntered
    private void A5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A5MouseEntered
        // TODO add your handling code here:
        A5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A5MouseEntered
    private void A6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A6MouseEntered
        // TODO add your handling code here:
        A6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A6MouseEntered
    private void A7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A7MouseEntered
        // TODO add your handling code here:
        A7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A7MouseEntered
    private void A8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A8MouseEntered
        // TODO add your handling code here:
        A8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A8MouseEntered
    private void A9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A9MouseEntered
        // TODO add your handling code here:
        A9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A9MouseEntered
    private void A10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A10MouseEntered
        // TODO add your handling code here:
        A10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_A10MouseEntered
    private void B1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B1MouseEntered
        // TODO add your handling code here:
        B1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B1MouseEntered
    private void B3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B3MouseEntered
        // TODO add your handling code here:
        B3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B3MouseEntered
    private void B4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B4MouseEntered
        // TODO add your handling code here:
        B4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B4MouseEntered
    private void B5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B5MouseEntered
        // TODO add your handling code here:
        B5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B5MouseEntered
    private void B6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B6MouseEntered
        // TODO add your handling code here:
        B6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B6MouseEntered
    private void B7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B7MouseEntered
        // TODO add your handling code here:
        B7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B7MouseEntered
    private void B8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B8MouseEntered
        // TODO add your handling code here:
        B8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B8MouseEntered
    private void B9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B9MouseEntered
        // TODO add your handling code here:
        B9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B9MouseEntered
    private void B10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B10MouseEntered
        // TODO add your handling code here:
        B10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B10MouseEntered
    private void C1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C1MouseEntered
        // TODO add your handling code here:
        C1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C1MouseEntered
    private void C2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C2MouseEntered
        // TODO add your handling code here:
        C2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C2MouseEntered
    private void C3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C3MouseEntered
        // TODO add your handling code here:
        C3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C3MouseEntered
    private void C4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C4MouseEntered
        // TODO add your handling code here:
        C4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C4MouseEntered
    private void C5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C5MouseEntered
        // TODO add your handling code here:
        C5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C5MouseEntered
    private void C6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C6MouseEntered
        // TODO add your handling code here:
        C6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C6MouseEntered
    private void C7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C7MouseEntered
        // TODO add your handling code here:
        C7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C7MouseEntered
    private void C8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C8MouseEntered
        // TODO add your handling code here:
        C8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C8MouseEntered
    private void C9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C9MouseEntered
        // TODO add your handling code here:
        C9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C9MouseEntered
    private void C10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C10MouseEntered
        // TODO add your handling code here:
        C10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_C10MouseEntered
    private void D1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D1MouseEntered
        // TODO add your handling code here:
        D1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D1MouseEntered
    private void D2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D2MouseEntered
        // TODO add your handling code here:
        D2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D2MouseEntered
    private void D3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D3MouseEntered
        // TODO add your handling code here:
        D3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D3MouseEntered
    private void D4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D4MouseEntered
        // TODO add your handling code here:
        D4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D4MouseEntered
    private void D5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D5MouseEntered
        // TODO add your handling code here:
        D5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D5MouseEntered
    private void D6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D6MouseEntered
        // TODO add your handling code here:
        D6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D6MouseEntered
    private void D7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D7MouseEntered
        // TODO add your handling code here:
        D7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D7MouseEntered
    private void D8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D8MouseEntered
        // TODO add your handling code here:
        D8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D8MouseEntered
    private void D9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D9MouseEntered
        // TODO add your handling code here:
        D9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D9MouseEntered
    private void D10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D10MouseEntered
        // TODO add your handling code here:
        D10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_D10MouseEntered
    private void E1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E1MouseEntered
        // TODO add your handling code here:
        E1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E1MouseEntered
    private void E2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E2MouseEntered
        // TODO add your handling code here:
        E2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E2MouseEntered
    private void E3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E3MouseEntered
        // TODO add your handling code here:
        E3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E3MouseEntered
    private void E4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E4MouseEntered
        // TODO add your handling code here:
        E4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E4MouseEntered
    private void E5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E5MouseEntered
        // TODO add your handling code here:
        E5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E5MouseEntered
    private void E6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E6MouseEntered
        // TODO add your handling code here:
        E6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E6MouseEntered
    private void E7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E7MouseEntered
        // TODO add your handling code here:
        E7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E7MouseEntered
    private void E8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E8MouseEntered
        // TODO add your handling code here:
        E8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E8MouseEntered
    private void E9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E9MouseEntered
        // TODO add your handling code here:
        E9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E9MouseEntered
    private void E10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E10MouseEntered
        // TODO add your handling code here:
        E10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_E10MouseEntered
    private void F1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F1MouseEntered
        // TODO add your handling code here:
        F1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F1MouseEntered
    private void F2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F2MouseEntered
        // TODO add your handling code here:
        F2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F2MouseEntered
    private void F3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F3MouseEntered
        // TODO add your handling code here:
        F3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F3MouseEntered
    private void F4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F4MouseEntered
        // TODO add your handling code here:
        F4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F4MouseEntered
    private void F5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F5MouseEntered
        // TODO add your handling code here:
        F5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F5MouseEntered
    private void F6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F6MouseEntered
        // TODO add your handling code here:
        F6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F6MouseEntered
    private void F7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F7MouseEntered
        // TODO add your handling code here:
        F7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F7MouseEntered
    private void F8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F8MouseEntered
        // TODO add your handling code here:
        F8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F8MouseEntered
    private void F9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F9MouseEntered
        // TODO add your handling code here:
        F9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F9MouseEntered
    private void F10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F10MouseEntered
        // TODO add your handling code here:
        F10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_F10MouseEntered
    private void G1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G1MouseEntered
        // TODO add your handling code here:
        G1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G1MouseEntered
    private void G2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G2MouseEntered
        // TODO add your handling code here:
        G2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G2MouseEntered
    private void G3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G3MouseEntered
        // TODO add your handling code here:
        G3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G3MouseEntered
    private void G4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G4MouseEntered
        // TODO add your handling code here:
        G4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G4MouseEntered
    private void G5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G5MouseEntered
        // TODO add your handling code here:
        G5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G5MouseEntered
    private void G6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G6MouseEntered
        // TODO add your handling code here:
        G6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G6MouseEntered
    private void G7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G7MouseEntered
        // TODO add your handling code here:
        G7.setBackground(new Color(236, 241, 199));

    }//GEN-LAST:event_G7MouseEntered
    private void G8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G8MouseEntered
        // TODO add your handling code here:
        G8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G8MouseEntered
    private void G9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G9MouseEntered
        // TODO add your handling code here:
        G9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G9MouseEntered
    private void G10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G10MouseEntered
        // TODO add your handling code here:
        G10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_G10MouseEntered
    private void H1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H1MouseEntered
        // TODO add your handling code here:
        H1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H1MouseEntered
    private void H2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H2MouseEntered
        // TODO add your handling code here:
        H2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H2MouseEntered
    private void H3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H3MouseEntered
        // TODO add your handling code here:
        H3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H3MouseEntered
    private void H4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H4MouseEntered
        // TODO add your handling code here:
        H4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H4MouseEntered
    private void H5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H5MouseEntered
        // TODO add your handling code here:
        H5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H5MouseEntered
    private void H6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H6MouseEntered
        // TODO add your handling code here:
        H6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H6MouseEntered
    private void H7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H7MouseEntered
        // TODO add your handling code here:
        H7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H7MouseEntered
    private void H8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H8MouseEntered
        // TODO add your handling code here:
        H8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H8MouseEntered
    private void H9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H9MouseEntered
        // TODO add your handling code here:
        H9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H9MouseEntered
    private void H10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H10MouseEntered
        // TODO add your handling code here:
        H10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_H10MouseEntered
    private void I1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I1MouseEntered
        // TODO add your handling code here:
        I1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I1MouseEntered
    private void I2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I2MouseEntered
        // TODO add your handling code here:
        I2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I2MouseEntered
    private void I3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I3MouseEntered
        // TODO add your handling code here:
        I3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I3MouseEntered
    private void I4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I4MouseEntered
        // TODO add your handling code here:
        I4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I4MouseEntered
    private void I5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I5MouseEntered
        // TODO add your handling code here:
        I5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I5MouseEntered
    private void I6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I6MouseEntered
        // TODO add your handling code here:
        I6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I6MouseEntered
    private void I7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I7MouseEntered
        // TODO add your handling code here:
        I7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I7MouseEntered
    private void I8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I8MouseEntered
        // TODO add your handling code here:
        I8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I8MouseEntered
    private void I9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I9MouseEntered
        // TODO add your handling code here:
        I9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I9MouseEntered
    private void I10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I10MouseEntered
        // TODO add your handling code here:
        I10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_I10MouseEntered
    private void L1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L1MouseEntered
        // TODO add your handling code here:
        L1.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L1MouseEntered
    private void L2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L2MouseEntered
        // TODO add your handling code here:
        L2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L2MouseEntered
    private void L3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L3MouseEntered
        // TODO add your handling code here:
        L3.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L3MouseEntered
    private void L4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L4MouseEntered
        // TODO add your handling code here:
        L4.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L4MouseEntered
    private void L5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L5MouseEntered
        // TODO add your handling code here:
        L5.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L5MouseEntered
    private void L6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L6MouseEntered
        // TODO add your handling code here:
        L6.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L6MouseEntered
    private void L7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L7MouseEntered
        // TODO add your handling code here:
        L7.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L7MouseEntered
    private void L8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L8MouseEntered
        // TODO add your handling code here:
        L8.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L8MouseEntered
    private void L9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L9MouseEntered
        // TODO add your handling code here:
        L9.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L9MouseEntered
    private void L10MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L10MouseEntered
        // TODO add your handling code here:
        L10.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_L10MouseEntered
    private void A3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A3MouseExited
        // TODO add your handling code here:
        A3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A3MouseExited
    private void A4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A4MouseExited
        // TODO add your handling code here:
        A4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A4MouseExited
    private void A5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A5MouseExited
        // TODO add your handling code here:
        A5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A5MouseExited
    private void A6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A6MouseExited
        // TODO add your handling code here:
        A6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A6MouseExited
    private void A7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A7MouseExited
        // TODO add your handling code here:
        A7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A7MouseExited
    private void A8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A8MouseExited
        // TODO add your handling code here:
        A8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A8MouseExited
    private void A9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A9MouseExited
        // TODO add your handling code here:
        A9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A9MouseExited
    private void A10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_A10MouseExited
        // TODO add your handling code here:
        A10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_A10MouseExited
    private void B1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B1MouseExited
        // TODO add your handling code here:
        B1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B1MouseExited
    private void B3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B3MouseExited
        // TODO add your handling code here:
        B3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B3MouseExited
    private void B4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B4MouseExited
        // TODO add your handling code here:
        B4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B4MouseExited
    private void B5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B5MouseExited
        // TODO add your handling code here:
        B5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B5MouseExited
    private void B6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B6MouseExited
        // TODO add your handling code here:
        B6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B6MouseExited
    private void B7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B7MouseExited
        // TODO add your handling code here:
        B7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B7MouseExited
    private void B8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B8MouseExited
        // TODO add your handling code here:
        B8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B8MouseExited
    private void B9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B9MouseExited
        // TODO add your handling code here:
        B9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B9MouseExited
    private void B10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B10MouseExited
        // TODO add your handling code here:
        B10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B10MouseExited
    private void C1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C1MouseExited
        // TODO add your handling code here:
        C1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C1MouseExited
    private void C2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C2MouseExited
        // TODO add your handling code here:
        C2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C2MouseExited
    private void C3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C3MouseExited
        // TODO add your handling code here:
        C3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C3MouseExited
    private void C4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C4MouseExited
        // TODO add your handling code here:
        C4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C4MouseExited
    private void C5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C5MouseExited
        // TODO add your handling code here:
        C5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C5MouseExited
    private void C6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C6MouseExited
        // TODO add your handling code here:
        C6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C6MouseExited
    private void C7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C7MouseExited
        // TODO add your handling code here:
        C7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C7MouseExited
    private void C8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C8MouseExited
        // TODO add your handling code here:
        C8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C8MouseExited
    private void C9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C9MouseExited
        // TODO add your handling code here:
        C9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C9MouseExited
    private void C10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_C10MouseExited
        // TODO add your handling code here:
        C10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_C10MouseExited
    private void D1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D1MouseExited
        // TODO add your handling code here:
        D1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D1MouseExited
    private void D2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D2MouseExited
        // TODO add your handling code here:
        D2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D2MouseExited
    private void D3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D3MouseExited
        // TODO add your handling code here:
        D3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D3MouseExited
    private void D4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D4MouseExited
        // TODO add your handling code here:
        D4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D4MouseExited
    private void D5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D5MouseExited
        // TODO add your handling code here:
        D5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D5MouseExited
    private void D6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D6MouseExited
        // TODO add your handling code here:
        D6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D6MouseExited
    private void D7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D7MouseExited
        // TODO add your handling code here:
        D7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D7MouseExited
    private void D8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D8MouseExited
        // TODO add your handling code here:
        D8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D8MouseExited
    private void D9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D9MouseExited
        // TODO add your handling code here:
        D9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D9MouseExited
    private void D10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_D10MouseExited
        // TODO add your handling code here:
        D10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_D10MouseExited
    private void E1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E1MouseExited
        // TODO add your handling code here:
        E1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E1MouseExited
    private void E2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E2MouseExited
        // TODO add your handling code here:
        E2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E2MouseExited
    private void E3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E3MouseExited
        // TODO add your handling code here:
        E3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E3MouseExited
    private void E4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E4MouseExited
        // TODO add your handling code here:
        E4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E4MouseExited
    private void E5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E5MouseExited
        // TODO add your handling code here:
        E5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E5MouseExited
    private void E6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E6MouseExited
        // TODO add your handling code here:
        E6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E6MouseExited
    private void E7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E7MouseExited
        // TODO add your handling code here:
        E7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E7MouseExited
    private void E8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E8MouseExited
        // TODO add your handling code here:
        E8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E8MouseExited
    private void E9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E9MouseExited
        // TODO add your handling code here:
        E9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E9MouseExited
    private void E10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_E10MouseExited
        // TODO add your handling code here:
        E10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_E10MouseExited
    private void F1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F1MouseExited
        // TODO add your handling code here:
        F1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F1MouseExited
    private void F2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F2MouseExited
        // TODO add your handling code here:
        F2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F2MouseExited
    private void F3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F3MouseExited
        // TODO add your handling code here:
        F3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F3MouseExited
    private void F4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F4MouseExited
        // TODO add your handling code here:
        F4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F4MouseExited
    private void F5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F5MouseExited
        // TODO add your handling code here:
        F5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F5MouseExited
    private void F6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F6MouseExited
        // TODO add your handling code here:
        F6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F6MouseExited
    private void F7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F7MouseExited
        // TODO add your handling code here:
        F7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F7MouseExited
    private void F8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F8MouseExited
        // TODO add your handling code here:
        F8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F8MouseExited
    private void F9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F9MouseExited
        // TODO add your handling code here:
        F9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F9MouseExited
    private void F10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_F10MouseExited
        // TODO add your handling code here:
        F10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_F10MouseExited
    private void G1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G1MouseExited
        // TODO add your handling code here:
        G1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G1MouseExited
    private void G2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G2MouseExited
        // TODO add your handling code here:
        G2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G2MouseExited
    private void G3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G3MouseExited
        // TODO add your handling code here:
        G3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G3MouseExited
    private void G4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G4MouseExited
        // TODO add your handling code here:
        G4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G4MouseExited
    private void G5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G5MouseExited
        // TODO add your handling code here:
        G5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G5MouseExited
    private void G6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G6MouseExited
        // TODO add your handling code here:
        G6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G6MouseExited
    private void G7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G7MouseExited
        // TODO add your handling code here:
        G7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G7MouseExited
    private void G8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G8MouseExited
        // TODO add your handling code here:
        G8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G8MouseExited
    private void G9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G9MouseExited
        // TODO add your handling code here:
        G9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G9MouseExited
    private void G10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_G10MouseExited
        // TODO add your handling code here:
        G10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_G10MouseExited
    private void H1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H1MouseExited
        // TODO add your handling code here:
        H1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H1MouseExited
    private void H2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H2MouseExited
        // TODO add your handling code here:
        H2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H2MouseExited
    private void H3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H3MouseExited
        // TODO add your handling code here:
        H3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H3MouseExited
    private void H4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H4MouseExited
        // TODO add your handling code here:
        H4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H4MouseExited
    private void H5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H5MouseExited
        // TODO add your handling code here:
        H5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H5MouseExited
    private void H6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H6MouseExited
        // TODO add your handling code here:
        H6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H6MouseExited
    private void H7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H7MouseExited
        // TODO add your handling code here:
        H7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H7MouseExited
    private void H8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H8MouseExited
        // TODO add your handling code here:
        H8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H8MouseExited
    private void H9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H9MouseExited
        // TODO add your handling code here:
        H9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H9MouseExited
    private void H10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_H10MouseExited
        // TODO add your handling code here:
        H10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_H10MouseExited
    private void I1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I1MouseExited
        // TODO add your handling code here:
        I1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I1MouseExited
    private void I2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I2MouseExited
        // TODO add your handling code here:
        I2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I2MouseExited
    private void I3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I3MouseExited
        // TODO add your handling code here:
        I3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I3MouseExited
    private void I4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I4MouseExited
        // TODO add your handling code here:
        I4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I4MouseExited
    private void I5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I5MouseExited
        // TODO add your handling code here:
        I5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I5MouseExited
    private void I6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I6MouseExited
        // TODO add your handling code here:
        I6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I6MouseExited
    private void I7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I7MouseExited
        // TODO add your handling code here:
        I7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I7MouseExited
    private void I8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I8MouseExited
        // TODO add your handling code here:
        I8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I8MouseExited
    private void I9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I9MouseExited
        // TODO add your handling code here:
        I9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I9MouseExited
    private void I10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_I10MouseExited
        // TODO add your handling code here:
        I10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_I10MouseExited
    private void L1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L1MouseExited
        // TODO add your handling code here:
        L1.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L1MouseExited
    private void L2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L2MouseExited
        // TODO add your handling code here:
        L2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L2MouseExited
    private void L3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L3MouseExited
        // TODO add your handling code here:
        L3.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L3MouseExited
    private void L4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L4MouseExited
        // TODO add your handling code here:
        L4.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L4MouseExited
    private void L5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L5MouseExited
        // TODO add your handling code here:
        L5.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L5MouseExited
    private void L6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L6MouseExited
        // TODO add your handling code here:
        L6.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L6MouseExited
    private void L7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L7MouseExited
        // TODO add your handling code here:
        L7.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L7MouseExited
    private void L8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L8MouseExited
        // TODO add your handling code here:
        L8.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L8MouseExited
    private void L9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L9MouseExited
        // TODO add your handling code here:
        L9.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L9MouseExited
    private void L10MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_L10MouseExited
        // TODO add your handling code here:
        L10.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_L10MouseExited
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        A1ship.setVisible(false);
        A2ship.setVisible(false);
        A3ship.setVisible(false);
        A4ship.setVisible(false);
        A5ship.setVisible(false);
        A6ship.setVisible(false);
        A7ship.setVisible(false);
        A8ship.setVisible(false);
        A9ship.setVisible(false);
        A10ship.setVisible(false);

        B1ship.setVisible(false);
        B2ship.setVisible(false);
        B3ship.setVisible(false);
        B4ship.setVisible(false);
        B5ship.setVisible(false);
        B6ship.setVisible(false);
        B7ship.setVisible(false);
        B8ship.setVisible(false);
        B9ship.setVisible(false);
        B10ship.setVisible(false);

        C1ship.setVisible(false);
        C2ship.setVisible(false);
        C3ship.setVisible(false);
        C4ship.setVisible(false);
        C5ship.setVisible(false);
        C6ship.setVisible(false);
        C7ship.setVisible(false);
        C8ship.setVisible(false);
        C9ship.setVisible(false);
        C10ship.setVisible(false);

        D1ship.setVisible(false);
        D2ship.setVisible(false);
        D3ship.setVisible(false);
        D4ship.setVisible(false);
        D5ship.setVisible(false);
        D6ship.setVisible(false);
        D7ship.setVisible(false);
        D8ship.setVisible(false);
        D9ship.setVisible(false);
        D10ship.setVisible(false);

        E1ship.setVisible(false);
        E2ship.setVisible(false);
        E3ship.setVisible(false);
        E4ship.setVisible(false);
        E5ship.setVisible(false);
        E6ship.setVisible(false);
        E7ship.setVisible(false);
        E8ship.setVisible(false);
        E9ship.setVisible(false);
        E10ship.setVisible(false);

        F1ship.setVisible(false);
        F2ship.setVisible(false);
        F3ship.setVisible(false);
        F4ship.setVisible(false);
        F5ship.setVisible(false);
        F6ship.setVisible(false);
        F7ship.setVisible(false);
        F8ship.setVisible(false);
        F9ship.setVisible(false);
        F10ship.setVisible(false);

        G1ship.setVisible(false);
        G2ship.setVisible(false);
        G3ship.setVisible(false);
        G4ship.setVisible(false);
        G5ship.setVisible(false);
        G6ship.setVisible(false);
        G7ship.setVisible(false);
        G8ship.setVisible(false);
        G9ship.setVisible(false);
        G10ship.setVisible(false);

        H1ship.setVisible(false);
        H2ship.setVisible(false);
        H3ship.setVisible(false);
        H4ship.setVisible(false);
        H5ship.setVisible(false);
        H6ship.setVisible(false);
        H7ship.setVisible(false);
        H8ship.setVisible(false);
        H9ship.setVisible(false);
        H10ship.setVisible(false);

        I1ship.setVisible(false);
        I2ship.setVisible(false);
        I3ship.setVisible(false);
        I4ship.setVisible(false);
        I5ship.setVisible(false);
        I6ship.setVisible(false);
        I7ship.setVisible(false);
        I8ship.setVisible(false);
        I9ship.setVisible(false);
        I10ship.setVisible(false);

        L1ship.setVisible(false);
        L2ship.setVisible(false);
        L3ship.setVisible(false);
        L4ship.setVisible(false);
        L5ship.setVisible(false);
        L6ship.setVisible(false);
        L7ship.setVisible(false);
        L8ship.setVisible(false);
        L9ship.setVisible(false);
        L10ship.setVisible(false);


    }//GEN-LAST:event_jButton1ActionPerformed
    private void label1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_label1MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_label1MouseClicked
    static PosizionaNavi window;
    private void B2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B2MouseClicked
        // TODO add your handling code here:
        B2ship.setVisible(true);
    }//GEN-LAST:event_B2MouseClicked

    private void B2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B2MouseEntered
        // TODO add your handling code here:
        B2.setBackground(new Color(236, 241, 199));
    }//GEN-LAST:event_B2MouseEntered

    private void B2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_B2MouseExited
        // TODO add your handling code here:
        B2.setBackground(new Color(255, 255, 240));
    }//GEN-LAST:event_B2MouseExited
    String NomeGiocatore;
    int porta;
    DatagramSocket server;

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        T.start();

        conteggio.setText(String.valueOf(ContatoreNavi));

        A1ship.setVisible(false);
        A2ship.setVisible(false);
        A3ship.setVisible(false);
        A4ship.setVisible(false);
        A5ship.setVisible(false);
        A6ship.setVisible(false);
        A7ship.setVisible(false);
        A8ship.setVisible(false);
        A9ship.setVisible(false);
        A10ship.setVisible(false);

        B1ship.setVisible(false);
        B2ship.setVisible(false);
        B3ship.setVisible(false);
        B4ship.setVisible(false);
        B5ship.setVisible(false);
        B6ship.setVisible(false);
        B7ship.setVisible(false);
        B8ship.setVisible(false);
        B9ship.setVisible(false);
        B10ship.setVisible(false);

        C1ship.setVisible(false);
        C2ship.setVisible(false);
        C3ship.setVisible(false);
        C4ship.setVisible(false);
        C5ship.setVisible(false);
        C6ship.setVisible(false);
        C7ship.setVisible(false);
        C8ship.setVisible(false);
        C9ship.setVisible(false);
        C10ship.setVisible(false);

        D1ship.setVisible(false);
        D2ship.setVisible(false);
        D3ship.setVisible(false);
        D4ship.setVisible(false);
        D5ship.setVisible(false);
        D6ship.setVisible(false);
        D7ship.setVisible(false);
        D8ship.setVisible(false);
        D9ship.setVisible(false);
        D10ship.setVisible(false);

        E1ship.setVisible(false);
        E2ship.setVisible(false);
        E3ship.setVisible(false);
        E4ship.setVisible(false);
        E5ship.setVisible(false);
        E6ship.setVisible(false);
        E7ship.setVisible(false);
        E8ship.setVisible(false);
        E9ship.setVisible(false);
        E10ship.setVisible(false);

        F1ship.setVisible(false);
        F2ship.setVisible(false);
        F3ship.setVisible(false);
        F4ship.setVisible(false);
        F5ship.setVisible(false);
        F6ship.setVisible(false);
        F7ship.setVisible(false);
        F8ship.setVisible(false);
        F9ship.setVisible(false);
        F10ship.setVisible(false);

        G1ship.setVisible(false);
        G2ship.setVisible(false);
        G3ship.setVisible(false);
        G4ship.setVisible(false);
        G5ship.setVisible(false);
        G6ship.setVisible(false);
        G7ship.setVisible(false);
        G8ship.setVisible(false);
        G9ship.setVisible(false);
        G10ship.setVisible(false);

        H1ship.setVisible(false);
        H2ship.setVisible(false);
        H3ship.setVisible(false);
        H4ship.setVisible(false);
        H5ship.setVisible(false);
        H6ship.setVisible(false);
        H7ship.setVisible(false);
        H8ship.setVisible(false);
        H9ship.setVisible(false);
        H10ship.setVisible(false);

        I1ship.setVisible(false);
        I2ship.setVisible(false);
        I3ship.setVisible(false);
        I4ship.setVisible(false);
        I5ship.setVisible(false);
        I6ship.setVisible(false);
        I7ship.setVisible(false);
        I8ship.setVisible(false);
        I9ship.setVisible(false);
        I10ship.setVisible(false);

        L1ship.setVisible(false);
        L2ship.setVisible(false);
        L3ship.setVisible(false);
        L4ship.setVisible(false);
        L5ship.setVisible(false);
        L6ship.setVisible(false);
        L7ship.setVisible(false);
        L8ship.setVisible(false);
        L9ship.setVisible(false);
        L10ship.setVisible(false);

    }//GEN-LAST:event_formWindowOpened
    int xmouse, ymouse;
    private void jPanel3MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MouseDragged
        // TODO add your handling code here:
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        setLocation(x - xmouse, y - ymouse);
    }//GEN-LAST:event_jPanel3MouseDragged

    private void jPanel3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MousePressed
        // TODO add your handling code here:

        xmouse = evt.getX();
        ymouse = evt.getY();
    }//GEN-LAST:event_jPanel3MousePressed

    public void NuovaConnessione(String nomeutente, int porta, PosizionaNavi c) throws SocketException {
        new PosizionaNavi().setVisible(true);
        NomeGiocatore = nomeutente;
        this.porta = porta;
        server = new DatagramSocket(porta);

    }
    /**
     * @param args the command line arguments
     */
    int tempo = 60;
    Timer T = new Timer(1000, new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            tempo--;
            if (tempo >= 0) {
                tempotimer.setText(String.valueOf(tempo + "s"));
            } else {
                System.exit(0);
            }
        }
    });

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PosizionaNavi().setVisible(true);
            }
        });

    }
    Conferma pn = new Conferma();

    public void FinePosizionamento() {

       
        this.setVisible(false);
        pn.NuovaConnessione("ciao",pn);
        System.out.println(porta);
    }

    public void AperturaConferma() throws SocketException {
        
        this.setVisible(false);
        pn.NuovaConnessione("ciao",pn);
        System.out.println(porta);

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel A1;
    private javax.swing.JPanel A10;
    private javax.swing.JLabel A10ship;
    private javax.swing.JLabel A1ship;
    private javax.swing.JPanel A2;
    private javax.swing.JLabel A2ship;
    private javax.swing.JPanel A3;
    private javax.swing.JLabel A3ship;
    private javax.swing.JPanel A4;
    private javax.swing.JLabel A4ship;
    private javax.swing.JPanel A5;
    private javax.swing.JLabel A5ship;
    private javax.swing.JPanel A6;
    private javax.swing.JLabel A6ship;
    private javax.swing.JPanel A7;
    private javax.swing.JLabel A7ship;
    private javax.swing.JPanel A8;
    private javax.swing.JLabel A8ship;
    private javax.swing.JPanel A9;
    private javax.swing.JLabel A9ship;
    private javax.swing.JPanel B1;
    private javax.swing.JPanel B10;
    private javax.swing.JLabel B10ship;
    private javax.swing.JLabel B1ship;
    private javax.swing.JPanel B2;
    private javax.swing.JLabel B2ship;
    private javax.swing.JPanel B3;
    private javax.swing.JLabel B3ship;
    private javax.swing.JPanel B4;
    private javax.swing.JLabel B4ship;
    private javax.swing.JPanel B5;
    private javax.swing.JLabel B5ship;
    private javax.swing.JPanel B6;
    private javax.swing.JLabel B6ship;
    private javax.swing.JPanel B7;
    private javax.swing.JLabel B7ship;
    private javax.swing.JPanel B8;
    private javax.swing.JLabel B8ship;
    private javax.swing.JPanel B9;
    private javax.swing.JLabel B9ship;
    private javax.swing.JPanel C1;
    private javax.swing.JPanel C10;
    private javax.swing.JLabel C10ship;
    private javax.swing.JLabel C1ship;
    private javax.swing.JPanel C2;
    private javax.swing.JLabel C2ship;
    private javax.swing.JPanel C3;
    private javax.swing.JLabel C3ship;
    private javax.swing.JPanel C4;
    private javax.swing.JLabel C4ship;
    private javax.swing.JPanel C5;
    private javax.swing.JLabel C5ship;
    private javax.swing.JPanel C6;
    private javax.swing.JLabel C6ship;
    private javax.swing.JPanel C7;
    private javax.swing.JLabel C7ship;
    private javax.swing.JPanel C8;
    private javax.swing.JLabel C8ship;
    private javax.swing.JPanel C9;
    private javax.swing.JLabel C9ship;
    private javax.swing.JPanel D1;
    private javax.swing.JPanel D10;
    private javax.swing.JLabel D10ship;
    private javax.swing.JLabel D1ship;
    private javax.swing.JPanel D2;
    private javax.swing.JLabel D2ship;
    private javax.swing.JPanel D3;
    private javax.swing.JLabel D3ship;
    private javax.swing.JPanel D4;
    private javax.swing.JLabel D4ship;
    private javax.swing.JPanel D5;
    private javax.swing.JLabel D5ship;
    private javax.swing.JPanel D6;
    private javax.swing.JLabel D6ship;
    private javax.swing.JPanel D7;
    private javax.swing.JLabel D7ship;
    private javax.swing.JPanel D8;
    private javax.swing.JLabel D8ship;
    private javax.swing.JPanel D9;
    private javax.swing.JLabel D9ship;
    private javax.swing.JPanel E1;
    private javax.swing.JPanel E10;
    private javax.swing.JLabel E10ship;
    private javax.swing.JLabel E1ship;
    private javax.swing.JPanel E2;
    private javax.swing.JLabel E2ship;
    private javax.swing.JPanel E3;
    private javax.swing.JLabel E3ship;
    private javax.swing.JPanel E4;
    private javax.swing.JLabel E4ship;
    private javax.swing.JPanel E5;
    private javax.swing.JLabel E5ship;
    private javax.swing.JPanel E6;
    private javax.swing.JLabel E6ship;
    private javax.swing.JPanel E7;
    private javax.swing.JLabel E7ship;
    private javax.swing.JPanel E8;
    private javax.swing.JLabel E8ship;
    private javax.swing.JPanel E9;
    private javax.swing.JLabel E9ship;
    private javax.swing.JPanel F1;
    private javax.swing.JPanel F10;
    private javax.swing.JLabel F10ship;
    private javax.swing.JLabel F1ship;
    private javax.swing.JPanel F2;
    private javax.swing.JLabel F2ship;
    private javax.swing.JPanel F3;
    private javax.swing.JLabel F3ship;
    private javax.swing.JPanel F4;
    private javax.swing.JLabel F4ship;
    private javax.swing.JPanel F5;
    private javax.swing.JLabel F5ship;
    private javax.swing.JPanel F6;
    private javax.swing.JLabel F6ship;
    private javax.swing.JPanel F7;
    private javax.swing.JLabel F7ship;
    private javax.swing.JPanel F8;
    private javax.swing.JLabel F8ship;
    private javax.swing.JPanel F9;
    private javax.swing.JLabel F9ship;
    private javax.swing.JPanel G1;
    private javax.swing.JPanel G10;
    private javax.swing.JLabel G10ship;
    private javax.swing.JLabel G1ship;
    private javax.swing.JPanel G2;
    private javax.swing.JLabel G2ship;
    private javax.swing.JPanel G3;
    private javax.swing.JLabel G3ship;
    private javax.swing.JPanel G4;
    private javax.swing.JLabel G4ship;
    private javax.swing.JPanel G5;
    private javax.swing.JLabel G5ship;
    private javax.swing.JPanel G6;
    private javax.swing.JLabel G6ship;
    private javax.swing.JPanel G7;
    private javax.swing.JLabel G7ship;
    private javax.swing.JPanel G8;
    private javax.swing.JLabel G8ship;
    private javax.swing.JPanel G9;
    private javax.swing.JLabel G9ship;
    private javax.swing.JPanel H1;
    private javax.swing.JPanel H10;
    private javax.swing.JLabel H10ship;
    private javax.swing.JLabel H1ship;
    private javax.swing.JPanel H2;
    private javax.swing.JLabel H2ship;
    private javax.swing.JPanel H3;
    private javax.swing.JLabel H3ship;
    private javax.swing.JPanel H4;
    private javax.swing.JLabel H4ship;
    private javax.swing.JPanel H5;
    private javax.swing.JLabel H5ship;
    private javax.swing.JPanel H6;
    private javax.swing.JLabel H6ship;
    private javax.swing.JPanel H7;
    private javax.swing.JLabel H7ship;
    private javax.swing.JPanel H8;
    private javax.swing.JLabel H8ship;
    private javax.swing.JPanel H9;
    private javax.swing.JLabel H9ship;
    private javax.swing.JPanel I1;
    private javax.swing.JPanel I10;
    private javax.swing.JLabel I10ship;
    private javax.swing.JLabel I1ship;
    private javax.swing.JPanel I2;
    private javax.swing.JLabel I2ship;
    private javax.swing.JPanel I3;
    private javax.swing.JLabel I3ship;
    private javax.swing.JPanel I4;
    private javax.swing.JLabel I4ship;
    private javax.swing.JPanel I5;
    private javax.swing.JLabel I5ship;
    private javax.swing.JPanel I6;
    private javax.swing.JLabel I6ship;
    private javax.swing.JPanel I7;
    private javax.swing.JLabel I7ship;
    private javax.swing.JPanel I8;
    private javax.swing.JLabel I8ship;
    private javax.swing.JPanel I9;
    private javax.swing.JLabel I9ship;
    private javax.swing.JPanel L1;
    private javax.swing.JPanel L10;
    private javax.swing.JLabel L10ship;
    private javax.swing.JLabel L1ship;
    private javax.swing.JPanel L2;
    private javax.swing.JLabel L2ship;
    private javax.swing.JPanel L3;
    private javax.swing.JLabel L3ship;
    private javax.swing.JPanel L4;
    private javax.swing.JLabel L4ship;
    private javax.swing.JPanel L5;
    private javax.swing.JLabel L5ship;
    private javax.swing.JPanel L6;
    private javax.swing.JLabel L6ship;
    private javax.swing.JPanel L7;
    private javax.swing.JLabel L7ship;
    private javax.swing.JPanel L8;
    private javax.swing.JLabel L8ship;
    private javax.swing.JPanel L9;
    private javax.swing.JLabel L9ship;
    private javax.swing.JLabel conteggio;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel105;
    private javax.swing.JPanel jPanel106;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private java.awt.Label label21;
    private java.awt.Label label22;
    private java.awt.Label label23;
    private java.awt.Label label24;
    private java.awt.Label label25;
    private java.awt.Label label26;
    private java.awt.Label label27;
    private java.awt.Label label28;
    private java.awt.Label label29;
    private java.awt.Label label30;
    private java.awt.Label label31;
    private java.awt.Label label32;
    private java.awt.Label label33;
    private java.awt.Label label34;
    private java.awt.Label label35;
    private java.awt.Label label36;
    private java.awt.Label label37;
    private java.awt.Label label38;
    private java.awt.Label label39;
    private java.awt.Label label40;
    private javax.swing.JLabel tempotimer;
    // End of variables declaration//GEN-END:variables
}
